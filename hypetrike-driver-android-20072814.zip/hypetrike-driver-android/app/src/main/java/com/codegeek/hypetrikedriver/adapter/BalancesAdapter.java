package com.codegeek.hypetrikedriver.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.BalanceTransaction;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class BalancesAdapter extends RecyclerView.Adapter<BalancesAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<BalanceTransaction> transactions;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView date, pickup, dropoff, total;

        public MyViewHolder(View view) {
            super(view);
            date = view.findViewById(R.id.tv_date);
            pickup = view.findViewById(R.id.tv_pickup);
            dropoff = view.findViewById(R.id.tv_dropoff);
            total = view.findViewById(R.id.tv_total);
        }
    }

    public BalancesAdapter(Context context, ArrayList<BalanceTransaction> transactions) {
        this.context = context;
        this.transactions = transactions;
    }

    public void setList(ArrayList<BalanceTransaction> transactions) {
        this.transactions = transactions;
        this.notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.list_item_transaction, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        BalanceTransaction tx = transactions.get(position);
        try {
            holder.date.setText(GeekUtility.changeDateFormat(tx.getTransactionDate(),
                    "yyyy-MM-dd HH:mm:ss",
                    "MMMM dd, yyyy, hh:mm a"));
        } catch (Exception e) {
            e.printStackTrace();
            holder.date.setText(tx.getTransactionDate());
        }
        holder.pickup.setText(tx.getPickupName());
        holder.dropoff.setText(tx.getDropoffName());
        holder.total.setText(String.format("Fare: P%.2f", tx.getTotalAmount()));
        Log.d("TEST", "--- tr: " + tx.getBalanceSummaryId());
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }
}
