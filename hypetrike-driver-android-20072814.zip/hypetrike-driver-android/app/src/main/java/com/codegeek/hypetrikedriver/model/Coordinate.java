package com.codegeek.hypetrikedriver.model;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONObject;

import java.io.Serializable;

public class Coordinate implements Serializable {

    private double lat;
    private double lng;

    public Coordinate(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put("lat", lat);
            json.put("lng", lng);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }

    public LatLng getLatLng(){
        return new LatLng(lat, lng);
    }
}
