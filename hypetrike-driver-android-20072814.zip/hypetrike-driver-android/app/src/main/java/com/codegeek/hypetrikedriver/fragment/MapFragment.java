package com.codegeek.hypetrikedriver.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.activity.MainActivity;
import com.codegeek.hypetrikedriver.api.MapsAPI;
import com.codegeek.hypetrikedriver.model.Booking;
import com.codegeek.hypetrikedriver.model.Coordinate;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.model.Route;
import com.codegeek.hypetrikedriver.util.GeekGUIUtility;
import com.codegeek.hypetrikedriver.util.GeekUtility;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.Locale;

public class MapFragment extends Fragment implements View.OnClickListener, OnMapReadyCallback, GoogleMap.OnMapClickListener {

    private static final String TAG = "TEST - MapFragment";
    private static final float DEFAULT_ZOOM = 18.5f;

    private HypeTrikePreferences mPref;
    private MapView mMapView;
    private GoogleMap mGoogleMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private LatLng mDefaultLocation;
    private LatLng mLatLng;
    private Location mLastKnownLocation;
    private Booking mBooking;
    private Route mRoute;
    private Marker mMyMarker;
    private Bitmap mMyLocBM;
    private Bitmap mPickupBM;
    private Bitmap mDestinationBM;
    private int mTripStatus = 0;

    private LinearLayout mParentTopNav;
    private TextView mTvRiderName;
    private TextView mTvFare;
    private ImageView mImgTopNavIcon;
    private TextView mTvTopNavLabel;
    private TextView mTvTopNavAddress;
    private TextView mBtnNavigate;
    private TextView mBtnCancel;
    private LinearLayout mParentBotNav;
    private LinearLayout mBtnMsg;
    private LinearLayout mBtnBotNavSubmit;
    private ImageView mImgBotNavIcon;
    private TextView mTvBotNavLabel;


    private String mToastMsg = "Unknown server error.";

    private static final int MSG_TOAST = 0;
    private static final int MSG_UPDATE_UI = 1;
    private static final int MSG_UPDATE_NAV_PICK_UP = 2;
    private static final int MSG_UPDATE_NAV_DROP_OFF = 3;
    private static final int MSG_UPDATE_NAV_RESET = 4;
    private static final int MSG_UPDATE_LOCATION = 5;

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_TOAST:
                    GeekUtility.hideProgressDialog(getContext());
                    GeekUtility.showToast(getContext(), mToastMsg);
                    break;
                case MSG_UPDATE_UI:
                    GeekUtility.hideProgressDialog(getContext());
                    updateMapUI();
                    break;
                case MSG_UPDATE_NAV_PICK_UP:
                    GeekUtility.hideProgressDialog(getContext());
                    mTvTopNavLabel.setText("Pick up:");
                    mTvTopNavAddress.setText(mRoute != null ? mRoute.getEndAddress() : "");
                    mTvBotNavLabel.setText("PICK UP");
                    mImgTopNavIcon.setBackgroundResource(0);
                    mImgBotNavIcon.setBackgroundResource(0);
                    mImgTopNavIcon.setImageResource(R.drawable.ic_pin_pickup);
                    mImgBotNavIcon.setImageResource(R.drawable.ic_baseline_location_on_24px);
                    mBtnBotNavSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ((MainActivity) getActivity()).showPickUpConfirmation();
                        }
                    });
                    break;
                case MSG_UPDATE_NAV_DROP_OFF:
                    GeekUtility.hideProgressDialog(getContext());
                    mTvTopNavLabel.setText("Drop off:");
                    mTvTopNavAddress.setText(mRoute != null ? mRoute.getEndAddress() : "");
                    mTvBotNavLabel.setText("DROP OFF");
                    mImgTopNavIcon.setBackgroundResource(0);
                    mImgBotNavIcon.setBackgroundResource(0);
                    mImgTopNavIcon.setImageResource(R.drawable.ic_pin_destination);
                    mImgBotNavIcon.setImageResource(R.drawable.ic_baseline_flag_white_24px);
                    mBtnBotNavSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ((MainActivity) getActivity()).showDropOffConfirmation();
                        }
                    });
                    break;
                case MSG_UPDATE_NAV_RESET:
                    GeekUtility.hideProgressDialog(getContext());
                    mTvTopNavLabel.setText("Pick up:");
                    mTvTopNavAddress.setText(mRoute != null ? mRoute.getEndAddress() : "");
                    mTvBotNavLabel.setText("PICK UP");
                    mImgTopNavIcon.setBackgroundResource(0);
                    mImgBotNavIcon.setBackgroundResource(0);
                    mImgTopNavIcon.setImageResource(R.drawable.ic_pin_pickup);
                    mImgBotNavIcon.setImageResource(R.drawable.ic_baseline_location_on_24px);
                    mBtnBotNavSubmit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ((MainActivity) getActivity()).showPickUpConfirmation();
                        }
                    });
                    mGoogleMap.clear();
                    if (mLastKnownLocation != null)
                        updateMyLocation(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()));
                    hideNavUI();
                    break;
                case MSG_UPDATE_LOCATION:
                    updateMyLocation(mLatLng);
                    break;
            }
        }
    };

    public static MapFragment newInstance() {
        return new MapFragment();
    }

    public MapFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_map, container, false);
        setupData();
        setupViews(rootView, savedInstanceState);
        return rootView;
    }

    private void setupData() {
        GeekUtility.initToast(getContext());
        mPref = new HypeTrikePreferences(getContext());
        // Default hard coded location - Calapan, Oriental Mindoro, PH
        mDefaultLocation = new LatLng(13.40622, 121.1765975);
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getContext());
        // Bitmaps for reuse
        int size = GeekUtility.getPXfromDP(getContext(), 40);
        mMyLocBM = GeekGUIUtility.getResizedBitmap(GeekGUIUtility.getBitmapFromVectorDrawable(getContext(),
                R.drawable.ic_trike), size, size);
        mPickupBM = GeekGUIUtility.getResizedBitmap(GeekGUIUtility.getBitmapFromVectorDrawable(getContext(),
                R.drawable.ic_baseline_place_24px), size, size);
        mDestinationBM = GeekGUIUtility.getResizedBitmap(GeekGUIUtility.getBitmapFromVectorDrawable(getContext(),
                R.drawable.ic_baseline_flag_24px), size, size);
    }


    private void setupViews(View rootView, Bundle savedInstanceState) {
        mMapView = rootView.findViewById(R.id.mapview);
        mMapView.onCreate(savedInstanceState);
        mMapView.onResume(); // needed to get the map to display immediately

        try {
            MapsInitializer.initialize(getContext());
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (getActivity() != null)
            mMapView.getMapAsync(this);

        // Top Nav
        mParentTopNav = rootView.findViewById(R.id.parent_top_nav);
        mTvRiderName = rootView.findViewById(R.id.tv_rider_name);
        mTvFare = rootView.findViewById(R.id.tv_fare);
        mImgTopNavIcon = rootView.findViewById(R.id.img_top_nav_icon);
        mTvTopNavLabel = rootView.findViewById(R.id.tv_top_nav_label);
        mTvTopNavAddress = rootView.findViewById(R.id.tv_top_nav_address);
        mBtnNavigate = rootView.findViewById(R.id.btn_navigate);
        mBtnNavigate.setOnClickListener(this);
        mBtnNavigate.setVisibility(View.GONE);
        mBtnCancel = rootView.findViewById(R.id.btn_cancel);
        mBtnCancel.setOnClickListener(this);
        mBtnCancel.setVisibility(View.GONE);
        mImgTopNavIcon.setBackgroundResource(R.drawable.ic_pin_pickup);

        // Bot Nav
        mParentBotNav = rootView.findViewById(R.id.parent_bot_nav);
        mBtnMsg = rootView.findViewById(R.id.btn_msg);
        mBtnBotNavSubmit = rootView.findViewById(R.id.btn_bot_nav_submit);
        mImgBotNavIcon = rootView.findViewById(R.id.img_bot_nav_icon);
        mTvBotNavLabel = rootView.findViewById(R.id.tv_bot_nav_label);
        mBtnMsg.setOnClickListener(this);
        // Initially set submit btn to PICK UP function
        mBtnBotNavSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) getActivity()).showPickUpConfirmation();
            }
        });

        mParentBotNav.setVisibility(View.GONE);
        mBtnMsg.setVisibility(View.GONE);
        mBtnBotNavSubmit.setVisibility(View.GONE);
        mImgBotNavIcon.setBackgroundResource(R.drawable.ic_baseline_location_on_24px);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_navigate:
                navigate();
                break;
            case R.id.btn_cancel:
                ((MainActivity) getActivity()).showCancelConfirmation();
                break;
            case R.id.btn_msg:
                ((MainActivity) getActivity()).showMessageDialog();
                break;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        mGoogleMap.setMaxZoomPreference(DEFAULT_ZOOM);
        mGoogleMap.setOnMapClickListener(this);

        // Load map custom style
//        try {
//            boolean success = mGoogleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(getContext(), R.raw.blue));
//            if (!success) {
//                Log.e(TAG, "----- Style parsing failed.");
//            }
//        } catch (Resources.NotFoundException e) {
//            Log.e(TAG, "----- Can't find style. Error: ", e);
//        }

        try {
            mGoogleMap.setMyLocationEnabled(false);
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(true);
            // getDeviceLocation();
            // Start thread for location update
            // updateLocation();
            // mLocHandler.post(mLocRunnable);
            // listenToLoc();
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapClick(LatLng latLng) {
        // Nothing to do yet...
    }

    /**
     * Gets the current location of the device, and positions the map's camera.
     * This is used for reinstating the UI based on the previous booking
     */
    private void getDeviceLocation() {
        /**
         * Get the best and most recent location of the device, which may be null in rare
         * cases when a location is not available.
         */
        try {
            Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
            locationResult.addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    if (task.isSuccessful() && task.getResult() != null) {
                        // Set the map's camera position to the current location of the device.
                        mLastKnownLocation = task.getResult();
                        LatLng latlng = new LatLng(mLastKnownLocation.getLatitude(),
                                mLastKnownLocation.getLongitude());
                        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                latlng, DEFAULT_ZOOM));

                        // location update moved to UpdateLocationService
                        // Log.d(TAG, "----- Device Location - latlng: " + latlng);
                        // ((MainActivity) getActivity()).locationUpdate(mPref.getUserId(), 0, latlng.latitude, latlng.longitude);

                        if (mTripStatus == 0) {
                            processRoute(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),
                                    mBooking.getPickup().getLatLng());
                        } else if (mTripStatus == 1) {
                            processRoute(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),
                                    mBooking.getDropoff().getLatLng());
                        }

                        // updateMyLocation(latlng);
                        // listenToLocChange();
                    } else {
                        Log.d(TAG, "Current location is null. Using defaults.");
                        Log.e(TAG, "Exception: %s", task.getException());
                        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mDefaultLocation, DEFAULT_ZOOM));
                        mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
                    }
                }
            });
        } catch (SecurityException e) {
            Log.e(TAG, "***** Error at getDeviceLocation()");
            e.printStackTrace();
        }
    }

    /**
     * Update pickup location using LatLng
     */
    private void updateMyLocation(LatLng latlng) {
        try {
            // Drop pin
            if (mMyMarker != null) {
                mMyMarker.remove();
            }
            mMyMarker = mGoogleMap.addMarker(new MarkerOptions()
                    .flat(true)
                    .position(latlng)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_trike))
                    .anchor(0.5f, 0.5f));
            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, DEFAULT_ZOOM));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Update map on activity life cycle events
     */

    @Override
    public void onDetach() {
        super.onDetach();
        getActivity().overridePendingTransition(R.anim.fadein, R.anim.slide_out_to_left);
    }

    @Override
    public void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mMapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mMapView.onLowMemory();
    }

    public void setBooking(Booking booking) {
        mBooking = booking;
        // start update location service
        if (mBooking != null)
            Log.d(TAG, "---- BID: " + mBooking.getId());
        else
            Log.e(TAG, "---- BID: NULL");
        // Create new service
        // UpdateLocationService.startUpdateLocation(getContext(), mBooking);
    }

    /**
     * Process route details from driver LOCATION to rider PICKUP
     */
    public void processRoute(final LatLng origin, final LatLng destination) {
        GeekUtility.showProgressDialog(getContext(), "Loading...");
        new Thread() {
            public void run() {
                Route route = MapsAPI.getRoute(getContext(), origin, destination);
                if (route != null) {
                    try {
                        mRoute = route;
                        mHandler.sendEmptyMessage(MSG_UPDATE_UI);
                    } catch (Exception e) {
                        e.printStackTrace();
                        mToastMsg = e.getMessage();
                        mHandler.sendEmptyMessage(MSG_TOAST);
                    }
                } else {
                    mToastMsg = MapsAPI.errorMessage;
                    mHandler.sendEmptyMessage(MSG_TOAST);
                }
            }
        }.start();
    }

    /**
     * Update map ui for PICKUP and DESTINATION
     */
    private void updateMapUI() {
        mGoogleMap.clear();
        if (mRoute != null) {
            // Start marker
            mMyMarker = mGoogleMap.addMarker(new MarkerOptions()
                    .position(mRoute.getStartLatLng())
                    .flat(true)
                    .icon(BitmapDescriptorFactory.fromBitmap(mMyLocBM))
                    .anchor(0.5f, 0.5f));

            // Destination marker
            Marker destination = mGoogleMap.addMarker(new MarkerOptions()
                    .position(mRoute.getEndLatLng()));

            switch (mTripStatus) {
                case 0: // driver loc -> pick up
                    mHandler.sendEmptyMessage(MSG_UPDATE_NAV_PICK_UP);
                    destination.setIcon(BitmapDescriptorFactory.fromBitmap(mPickupBM));
                    break;
                case 1: // driver loc (pick up) -> destination
                    mHandler.sendEmptyMessage(MSG_UPDATE_NAV_DROP_OFF);
                    destination.setIcon(BitmapDescriptorFactory.fromBitmap(mDestinationBM));
                    break;
            }

            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(mRoute.getStartLatLng());
            builder.include(mRoute.getEndLatLng());
            LatLngBounds bounds = builder.build();

            int padding = GeekUtility.getPXfromDP(getContext(), 50);
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);

            try {
                mGoogleMap.animateCamera(cu);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e(TAG, "--- error: " + e.getMessage());
                padding = GeekUtility.getPXfromDP(getContext(), 25);
                cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                mGoogleMap.animateCamera(cu);
            }
            displayDirection();
            showNavUI();
        }
    }

    /**
     * Show route using polylines / paths from route object
     */
    private void displayDirection() {
        for (String encoded : mRoute.getPaths()) {
            PolylineOptions options = new PolylineOptions();
            options.color(getResources().getColor(R.color.blue4));
            options.width(GeekUtility.getPXfromDP(getContext(), 5));
            options.addAll(GeekUtility.decodePoly(encoded));
            mGoogleMap.addPolyline(options);
        }
    }

    /**
     * Navigate using WAZE or other maps applications
     */
    private void navigate() {
        boolean hasWaze = false;
        try {
            PackageManager pm = getActivity().getPackageManager();
            PackageInfo info = pm.getPackageInfo("com.waze", PackageManager.GET_ACTIVITIES);
            if (info != null)
                hasWaze = true;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "----- Waze app not found!");
            hasWaze = false;
        } catch (Exception e) {
            Log.e(TAG, "----- Error checking waze app, " + e.getMessage());
            hasWaze = false;
        }

        String uri = null;
        Intent intent;
        try {
            if (hasWaze) {
                uri = "waze://?ll=" + mRoute.getEndLatLng().latitude + ", "
                        + mRoute.getEndLatLng().longitude + "&navigate=yes";
            } else {
                String data[] = mRoute.getEndAddress().split(",");
                String address = data[0] + ", " + data[1];
                if (data.length >= 3) {
                    address = data[0] + ", " + data[1] + "," + data[2];
                }
                uri = String.format(Locale.ENGLISH, "geo:" + mRoute.getEndLatLng().latitude + ","
                        + mRoute.getEndLatLng().longitude + "?q="
                        + mRoute.getEndLatLng().latitude + ","
                        + mRoute.getEndLatLng().longitude + " ("
                        + address + ")");
            }
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            try {
                Intent unrestrictedIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(unrestrictedIntent);
            } catch (ActivityNotFoundException innerEx) {
                mToastMsg = "No map application found.";
                mHandler.sendEmptyMessage(MSG_TOAST);
            }
        }
    }

    /**
     * Show nav UI and other trip details
     */
    private void showNavUI() {
        // Top nav
        mParentTopNav.setVisibility(View.VISIBLE);
        mBtnNavigate.setVisibility(View.VISIBLE);
        mBtnCancel.setVisibility(View.VISIBLE);
        TranslateAnimation animate1 = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                -700, // fromYDelta
                0); // toYDelta
        animate1.setDuration(1000);
        animate1.setFillAfter(true);
        mParentTopNav.startAnimation(animate1);
        mTvRiderName.setText(mBooking.getRiderFullName());
        mTvFare.setText(String.format("Fare: P%.2f", mBooking.getPrice().getTotal()));

        // Bot Nav
        mParentBotNav.setVisibility(View.VISIBLE);
        mBtnMsg.setVisibility(View.VISIBLE);
        mBtnBotNavSubmit.setVisibility(View.VISIBLE);
        TranslateAnimation animate2 = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                700, // fromYDelta
                0); // toYDelta
        animate2.setDuration(1000);
        animate2.setFillAfter(true);
        mParentBotNav.startAnimation(animate2);
    }

    /**
     * Hide nav UI and other trip details
     */
    public void hideNavUI() {
        // Top nav
        TranslateAnimation animate1 = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                0, // fromYDelta
                -700); // toYDelta
        animate1.setDuration(500);
        animate1.setFillAfter(true);
        animate1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // do nothing...
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mParentTopNav.setVisibility(View.GONE);
                mBtnNavigate.setVisibility(View.GONE);
                mBtnCancel.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // do nothing...
            }
        });
        mParentTopNav.startAnimation(animate1);

        // Bot Nav
        TranslateAnimation animate2 = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                0, // fromYDelta
                700); // toYDelta
        animate2.setDuration(500);
        animate2.setFillAfter(true);
        animate2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // do nothing...
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mParentBotNav.setVisibility(View.GONE);
                mBtnMsg.setVisibility(View.GONE);
                mBtnBotNavSubmit.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // do nothing...
            }
        });
        mParentBotNav.startAnimation(animate2);
    }

    /**
     * Update top and bot nav UI fr driver loc to PICK UP
     */
    public void processPickUpRoute() {
        // create new route: driver loc to the PICK UP point
        mTripStatus = 0;
        if (mLastKnownLocation == null) {
            getDeviceLocation();
        } else {
            processRoute(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),
                    mBooking.getPickup().getLatLng());
        }
    }

    /**
     * Update top and bot nav UI fr PICK UP to DROP OFF
     */
    public void processDropOffRoute() {
        // create new route: driver loc to the DROP OFF point
        mTripStatus = 1;
        if (mLastKnownLocation == null) {
            getDeviceLocation();
        } else {
            processRoute(new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude()),
                    mBooking.getDropoff().getLatLng());
        }
    }

    /**
     * Update top and bot nav UI back to PICK UP fr DROP OFF
     */
    public void resetNav() {
        mHandler.sendEmptyMessage(MSG_UPDATE_NAV_RESET);
    }

    public void updateLocation(Coordinate coor) {
        mLatLng = new LatLng(coor.getLat(), coor.getLng());
        mHandler.sendEmptyMessage(MSG_UPDATE_LOCATION);
    }

    /**
     * Driver location updater
     */
//    private Handler mLocHandler1 = new Handler();
//    private Runnable mLocRunnable1 = new Runnable() {
//        @Override
//        public void run() {
//            // Do something here on the main thread
//            try {
//                if (mMapView.isShown()) {
//                    Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
//                    locationResult.addOnCompleteListener(getActivity(), new OnCompleteListener<Location>() {
//                        @Override
//                        public void onComplete(@NonNull Task<Location> task) {
//                            if (task.isSuccessful() && task.getResult() != null) {
//                                // Compute for the distance change - in meters
//
//                                // float dist = task.getResult().distanceTo(mLastKnownLocation);
//                                // if (dist > 5.0f) { // 5 meters
//                                //     Log.d(TAG, "----- Location changed! distance: " + dist);
//
//                                mLastKnownLocation = task.getResult();
//                                // Log.d(TAG, "----- location update: " + mLastKnownLocation.getLatitude() + " | " + mLastKnownLocation.getLongitude());
//                                LatLng latlng = new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
//                                mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, DEFAULT_ZOOM));
//                                updateMyLocation(latlng);
//
//                                long bid = 0;
//                                if (mBooking != null) {
//                                    bid = mBooking.getId();
//                                }
//                                // Send location update to server
//                                ((MainActivity) getActivity()).locationUpdate(mPref.getUserId(), bid, mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
//                            }
//                        }
//                    });
//                }
//            } catch (SecurityException se) {
//                se.printStackTrace();
//                Log.e(TAG, se.getMessage());
//            } catch (Exception e) {
//                e.printStackTrace();
//                Log.e(TAG, e.getMessage());
//            }
//            // Repeat this the same runnable code block again another X ms (1000 ms = 1 sec)
//            // 'this' is referencing the Runnable object
//            long x = 5000; // 1000 ms = 1 sec
//            mLocHandler.postDelayed(this, x);
//        }
//    };
//
//    private void listenToLoc(){
//        try {
//            LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
//            // Define a listener that responds to location updates
//            LocationListener locationListener = new LocationListener() {
//                public void onLocationChanged(Location location) {
//                    // Called when a new location is found by the network location provider.
//                    mLastKnownLocation = location;
//                    Log.d(TAG, "----- location update: " + mLastKnownLocation.getLatitude()
//                            + " | " + mLastKnownLocation.getLongitude());
//                    LatLng latlng = new LatLng(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
//                    mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, DEFAULT_ZOOM));
//                    updateMyLocation(latlng);
//
//                    long bid = 0;
//                    if (mBooking != null) {
//                        bid = mBooking.getId();
//                    }
//                    // Send location update to server
//                    ((MainActivity) getActivity()).locationUpdate(mPref.getUserId(), bid, mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
//                }
//
//                public void onStatusChanged(String provider, int status, Bundle extras) {}
//
//                public void onProviderEnabled(String provider) {}
//
//                public void onProviderDisabled(String provider) {}
//            };
//            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
//            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
//        } catch (SecurityException se) {
//            se.printStackTrace();
//            Log.e(TAG, se.getMessage());
//        }  catch (Exception e) {
//            e.printStackTrace();
//            Log.e(TAG, e.getMessage());
//        }
//    }
}
