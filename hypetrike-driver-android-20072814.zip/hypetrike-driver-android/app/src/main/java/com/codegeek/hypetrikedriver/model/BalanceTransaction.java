package com.codegeek.hypetrikedriver.model;

public class BalanceTransaction {

    private long balanceSummaryId;
    private int type;
    private double totalAmount;
    private long bookingId;
    private String transactionDate;
    private Coordinate pickup;
    private Coordinate dropoff;
    private String pickupName;
    private String dropoffName;

    public BalanceTransaction(long balanceSummaryId, int type, double totalAmount, long bookingId,
                              String transactionDate, Coordinate pickup, Coordinate dropoff,
                              String pickupName, String dropoffName) {
        this.balanceSummaryId = balanceSummaryId;
        this.type = type;
        this.totalAmount = totalAmount;
        this.bookingId = bookingId;
        this.transactionDate = transactionDate;
        this.pickup = pickup;
        this.dropoff = dropoff;
        this.pickupName = pickupName;
        this.dropoffName = dropoffName;
    }

    public long getBalanceSummaryId() {
        return balanceSummaryId;
    }

    public void setBalanceSummaryId(long balanceSummaryId) {
        this.balanceSummaryId = balanceSummaryId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public long getBookingId() {
        return bookingId;
    }

    public void setBookingId(long bookingId) {
        this.bookingId = bookingId;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public Coordinate getPickup() {
        return pickup;
    }

    public void setPickup(Coordinate pickup) {
        this.pickup = pickup;
    }

    public Coordinate getDropoff() {
        return dropoff;
    }

    public void setDropoff(Coordinate dropoff) {
        this.dropoff = dropoff;
    }

    public String getPickupName() {
        return pickupName;
    }

    public void setPickupName(String pickupName) {
        this.pickupName = pickupName;
    }

    public String getDropoffName() {
        return dropoffName;
    }

    public void setDropoffName(String dropoffName) {
        this.dropoffName = dropoffName;
    }
}
