package com.codegeek.hypetrikedriver.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.adapter.TransactionsAdapter;
import com.codegeek.hypetrikedriver.api.DataAPI;
import com.codegeek.hypetrikedriver.model.DriverTransaction;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class TransactionsFragment extends Fragment {

    private HypeTrikePreferences mPref;
    private DriverTransaction mTransaction;
    private ArrayList<DriverTransaction.Transaction> mTransactions;
    private TransactionsAdapter mAdapter;
    private String mCurrentParam;
    private String mToastMessage = "";

    private SwipeRefreshLayout mParentSRL;
    private RecyclerView mRecyclerView;
    private TextView mNoItemsLabel;

    private boolean isServerLoading = false;
    private int queryOffset = 0;
    private int pageSize = 10;

    private static final int MSG_UPDATE_LIST = 0;
    private static final int MSG_TOAST = 1;

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_UPDATE_LIST:
                    GeekUtility.hideProgressDialog(getContext());
                    if (mTransactions == null || mTransactions.isEmpty()) {
                        mAdapter.setList(new ArrayList<DriverTransaction.Transaction>());
                        mRecyclerView.setVisibility(View.GONE);
                        mNoItemsLabel.setVisibility(View.VISIBLE);
                    } else {
                        mAdapter.setList(mTransactions);
                        mRecyclerView.setVisibility(View.VISIBLE);
                        mNoItemsLabel.setVisibility(View.GONE);
                    }
                    mParentSRL.setRefreshing(false);
                    break;
                case MSG_TOAST:
                    GeekUtility.hideProgressDialog(getContext());
                    GeekUtility.showToast(getContext(), mToastMessage);
                    break;
            }
        }
    };

    public static TransactionsFragment newInstance() {
        return new TransactionsFragment();
    }

    public TransactionsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_transactions, container, false);
        setupData();
        setupViews(rootView);
        fetchData(queryOffset, pageSize);
        return rootView;
    }

    private void setupData() {
        mPref = new HypeTrikePreferences(getContext());
        mTransactions = new ArrayList<>();
        mAdapter = new TransactionsAdapter(getContext(), mTransactions);
    }

    private void setupViews(View rootView) {
        mParentSRL = rootView.findViewById(R.id.parent_srl);
        // Setup refresh listener which triggers new data loading
        mParentSRL.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call mParentSRL.setRefreshing(false)
                // once the network request has completed successfully.
                mTransactions = new ArrayList<>();
                queryOffset = 0;
                pageSize = 10;
                fetchData(queryOffset, pageSize);
            }
        });


        mNoItemsLabel = rootView.findViewById(R.id.tv_no_items);

        mRecyclerView = rootView.findViewById(R.id.rv_transaction_list);
        mRecyclerView.setAdapter(mAdapter);

        final LinearLayoutManager lm = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(lm);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int visibleItemCount = lm.getChildCount();
                int totalItemCount = lm.getItemCount();
                int firstVisibleItemPosition = lm.findFirstVisibleItemPosition();

                // Load more if we have reach the end to the recyclerView
                if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount && firstVisibleItemPosition >= 0) {
                    loadMoreItems();
                }

            }
        });

        mRecyclerView.setVisibility(View.GONE);
        mNoItemsLabel.setVisibility(View.VISIBLE);
    }

    private void fetchData(final int offset, final int pageSize) {
        if (isServerLoading) {
            Log.e("TEST", "----- fetchData() - still fetching transactions... " + mTransactions.size());
            return;
        }

        GeekUtility.showProgressDialog(getContext(), "Loading transaction list...");
        isServerLoading = true;
        new Thread() {
            public void run() {
                try {
                    DriverTransaction transaction = DataAPI.getTransactions(mPref.getUserId(),
                            offset, pageSize, mCurrentParam);
                    if (transaction != null) {
                        mCurrentParam = transaction.getParam();
                        ArrayList<DriverTransaction.Transaction> newItems = transaction.getTransactions();
                        Log.e("TEST", "----- param: " + mCurrentParam);
                        Log.e("TEST", "----- transactions: " + newItems.size());
                        if (newItems.size() > 0) {
                            mTransactions.addAll(newItems);
                            isServerLoading = false;
                            mHandler.sendEmptyMessage(MSG_UPDATE_LIST);
                        } else {
                            isServerLoading = false;
                            mToastMessage = "All transactions loaded";
                            mHandler.sendEmptyMessage(MSG_TOAST);
                        }
                    } else {
                        isServerLoading = false;
                        mToastMessage = DataAPI.errorMessage;
                        mHandler.sendEmptyMessage(MSG_TOAST);
                    }
                } catch (Exception e) {
                    Log.e("TEST", "----- Error on transactions.fetchData()");
                    e.printStackTrace();
                    isServerLoading = false;
                    mToastMessage = e.getMessage();
                    mHandler.sendEmptyMessage(MSG_TOAST);
                }
            }
        }.start();
    }

    private void loadMoreItems() {
        // init offset=0 the frist time and increase the offset + the PAGE_SIZE when loading more items
        queryOffset = queryOffset + pageSize;
        // HERE YOU LOAD the next batch of items
        fetchData(queryOffset, pageSize);
    }
}
