package com.codegeek.hypetrikedriver.api;

import android.util.Log;

import com.codegeek.hypetrikedriver.model.Balance;
import com.codegeek.hypetrikedriver.model.BalanceTransaction;
import com.codegeek.hypetrikedriver.model.Coordinate;
import com.codegeek.hypetrikedriver.model.DriverTransaction;
import com.codegeek.hypetrikedriver.model.HypeTrikeConstants;
import com.codegeek.hypetrikedriver.model.NotificationMsg;
import com.codegeek.hypetrikedriver.model.Status;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.ConnectException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DataAPI {
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static String errorMessage = "Unknown error occurred.";

    public static DriverTransaction getTransactions(long uid, int index, int size, String param) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/transactions")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", uid);
            jObject.put("index", index);
            jObject.put("size", size);
            jObject.put("param", param);
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Log.e("TEST", "======= body: " + jObject.toString());
            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            Log.d("TEST", "======= code: " + code);
            if (!code.equalsIgnoreCase(Status.SUCCESS_GET_TRANSACTIONS)) {
                errorMessage = jResult.getString("statusMessage");
                if (errorMessage.isEmpty()) {
                    if (code.equalsIgnoreCase(Status.FAIL_GET_TRANSACTIONS_INVALID_UID)) {
                        errorMessage = "Sorry. Unable to get transactions. (Invalid user id)";
                    }
                }
                return null;
            }

            String currentParam = jResult.getString("param");

            ArrayList<DriverTransaction.Transaction> transactions = new ArrayList<>();
            JSONArray arrTxs;
            try {
                arrTxs = jResult.getJSONArray("transaction");
            } catch (Exception e) {
                e.printStackTrace();
                arrTxs = new JSONArray();
            }
            for (int i = 0; i < arrTxs.length(); i++) {
                JSONObject obj = arrTxs.getJSONObject(i);
                String date = obj.getString("transactionDate");
                long bookingId = obj.getLong("bookingId");
                double totalPrice = obj.getDouble("totalPrice");
                JSONObject jPickup = obj.getJSONObject("pickup");
                Coordinate pickup = new Coordinate(jPickup.getDouble("lat"),
                        jPickup.getDouble("lng"));
                JSONObject jDropoff = obj.getJSONObject("dropoff");
                Coordinate dropoff = new Coordinate(jDropoff.getDouble("lat"),
                        jDropoff.getDouble("lng"));
                String pickupName = obj.getString("pickupName");
                String dropoffName = obj.getString("dropoffName");
                transactions.add(new DriverTransaction.Transaction(date, bookingId, totalPrice,
                        pickup, dropoff, pickupName, dropoffName));
            }

            Log.d("TEST", "======= code: " + code);
            return new DriverTransaction(currentParam, transactions);
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return null;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return null;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return null;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return null;
        }
    }

    public static Balance getBalances(long uid, int index, int size, String param, String startDate, String endDate) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/balancetransactions")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", uid);
            jObject.put("index", index);
            jObject.put("size", size);
            jObject.put("param", param);
            jObject.put("startDate", startDate);
            jObject.put("endDate", endDate);
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Log.d("TEST", "======= body: " + jObject.toString());
            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            Log.d("TEST", "======= code: " + code);
            if (!code.equalsIgnoreCase(Status.SUCCESS_GET_BALANCES)) {
                errorMessage = jResult.getString("statusMessage");
                if (errorMessage.isEmpty()) {
                    if (code.equalsIgnoreCase(Status.FAIL_GET_BALANCES_INVALID_UID)) {
                        errorMessage = "Sorry. Unable to get balance transactions. (Invalid user id)";
                    }
                }
                return null;
            }

            double current = jResult.getString("balance") == "null" ? 0 : jResult.getDouble("balance");
            String currentParam = jResult.getString("param");

            ArrayList<BalanceTransaction> transactions = new ArrayList<>();
            JSONArray arrTxs;
            try {
                arrTxs = jResult.getJSONArray("transaction");
            } catch (Exception e) {
                e.printStackTrace();
                arrTxs = new JSONArray();
            }
            for (int i = 0; i < arrTxs.length(); i++) {
                JSONObject obj = arrTxs.getJSONObject(i);
                long balanceSummaryId = obj.getLong("balanceSummaryId");
                int type = obj.getInt("type");
                long bookingId = obj.getString("bookingId") == "null" ? -1 : obj.getLong("bookingId");
                double totalAmount = obj.getDouble("totalAmount");
                String transactionDate = obj.getString("transactionDate");
                JSONObject jPickup = obj.getJSONObject("pickup");
                Coordinate pickup = new Coordinate(
                        jPickup.getString("lat") == "null" ? 0 : jPickup.getDouble("lat"),
                        jPickup.getString("lng") == "null" ? 0 : jPickup.getDouble("lng"));
                JSONObject jDropoff = obj.getJSONObject("dropoff");
                Coordinate dropoff = new Coordinate(
                        jDropoff.getString("lat") == "null" ? 0 : jDropoff.getDouble("lat"),
                        jDropoff.getString("lng") == "null" ? 0 : jDropoff.getDouble("lng"));
                String pickupName = obj.getString("pickupName");
                String dropoffName = obj.getString("dropoffName");
                transactions.add(new BalanceTransaction(balanceSummaryId, type, totalAmount,
                        bookingId, transactionDate, pickup, dropoff, pickupName, dropoffName));
            }

            Log.d("TEST", "======= code: " + code);
            return new Balance(current, currentParam, transactions);
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return null;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return null;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return null;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<NotificationMsg> getNotifications(long uid, int index, int size) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/notifications")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", uid);
            jObject.put("index", index);
            jObject.put("size", size);
            jObject.put("param", null);
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            // Log.d("TEST", "======= body: " + jObject.toString());
            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            Log.d("TEST", "======= code: " + code);
            if (!code.equalsIgnoreCase(Status.SUCCESS_GET_NOTIFICATIONS)) {
                errorMessage = jResult.getString("statusMessage");
                if (errorMessage.isEmpty()) {
                    if (code.equalsIgnoreCase(Status.FAIL_GET_NOTIFICATIONS_INVALID_UID)) {
                        errorMessage = "Sorry. Unable to get transactions. (Invalid user id)";
                    }
                }
                return null;
            }

            ArrayList<NotificationMsg> notifications = new ArrayList<>();
            JSONArray arrTxs;
            try {
                arrTxs = jResult.getJSONArray("notification");
            } catch (Exception e) {
                e.printStackTrace();
                arrTxs = new JSONArray();
            }
            for (int i = 0; i < arrTxs.length(); i++) {
                JSONObject obj = arrTxs.getJSONObject(i);
                long id = obj.getLong("notificationId");
                String senderName = obj.getString("senderName");
                String message = obj.getString("message");
                String dateTime = obj.getString("dateTime");
                notifications.add(new NotificationMsg(id, senderName, message, dateTime));
            }
            return notifications;
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return null;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return null;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return null;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred on getting transactions.";
            e.printStackTrace();
            return null;
        }
    }


}
