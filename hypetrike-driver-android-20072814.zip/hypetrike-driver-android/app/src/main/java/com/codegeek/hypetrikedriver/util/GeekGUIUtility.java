package com.codegeek.hypetrikedriver.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class GeekGUIUtility {

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {
            // Calculate ratios of height and width to requested height and
            // width
            final int heightRatio = Math.round((float) height
                    / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will
            // guarantee a final image with both dimensions larger than or
            // equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        // Log.d("TEST", ">>>> inSampleSize = " + inSampleSize);
        return inSampleSize;
    }

    public static Bitmap decodeResource(Resources res, int resId, int reqWidth,
                                        int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth,
                reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    public static Bitmap decodeByteArray(byte[] data, int offset, int length,
                                         int reqWidth, int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, offset, length, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth,
                reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeByteArray(data, offset, length, options);
    }

    public static Bitmap decodeStream(ZipFile zFile, ZipEntry zEntry,
                                      Rect outPadding, int reqWidth, int reqHeight) {
        try {
            InputStream is = zFile.getInputStream(zEntry);
            // First decode with inJustDecodeBounds=true to check dimensions
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, outPadding, options);
            is.close();
            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize(options, reqWidth,
                    reqHeight);

            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            is = zFile.getInputStream(zEntry);
            Bitmap bm = BitmapFactory.decodeStream(is, outPadding, options);
            is.close();
            return bm;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap decodeStream(String url, int reqWidth, int reqHeight) {
        Log.d("TEST", "***** decodeStream::URL() *****");
        Log.d("TEST", "--- url: " + url);

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        try {
            URL mUrl = new URL(url);
            BitmapFactory.decodeStream(mUrl.openConnection().getInputStream(),
                    null, options);

            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize(options, reqWidth,
                    reqHeight);

            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(mUrl.openConnection()
                    .getInputStream(), null, options);
        } catch (Exception e) {
            Log.d("TEST", "***** ERROR @ decodeFile::URL() *****");
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap decodeFile(String url, int reqWidth, int reqHeight) {
        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(url, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth,
                reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(url, options);
    }

    public static Bitmap getCircularBitmap(Bitmap bitmap, int color) {

        Bitmap output;
        bitmap = getResizedBitmap(bitmap, 400, 400);
        output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(),
                Config.ARGB_8888);

        // Put bitmap over a white square bitmap
        Config conf1 = Config.ARGB_8888;
        Bitmap bmp1 = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(),
                conf1);
        bmp1.eraseColor(Color.WHITE);

        bitmap = overlay(bmp1, bitmap);

        Canvas canvas = new Canvas(output);
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        // Log.d("TEST", ">>>> r: " + r);

        // prepare canvas for transfer
        paint.setAntiAlias(true);
        paint.setColor(0xFFFFFFFF);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawARGB(0, 0, 0, 0);
        canvas.drawCircle(r, r, r, paint);

        // draw bitmap
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        // draw border
        // paint.setColor(0xFFD6D6D6);
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((float) 30);
        canvas.drawCircle(r, r, r, paint);

        return output;
    }

    public static Bitmap overlay(Bitmap bmp1, Bitmap bmp2) {
        Bitmap bmOverlay = Bitmap.createBitmap(bmp1.getWidth(),
                bmp1.getHeight(), bmp1.getConfig());
        Canvas canvas = new Canvas(bmOverlay);
        canvas.drawBitmap(bmp1, new Matrix(), null);
        // canvas.drawBitmap(bmp2, new Matrix(), null);
        canvas.drawBitmap(bmp2, 0, 0, null);
        return bmOverlay;
    }

    /**
     * @param d     diameter
     * @param t     stroke thickness
     * @param color color resource ID
     */
    public static Bitmap getCircularBitmap(int d, int t, int color) {
        Bitmap output = Bitmap.createBitmap(d, d, Config.ARGB_8888);

        Canvas canvas = new Canvas(output);
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, d, d);

        float r = d / 2;

        // prepare canvas for transfer
        paint.setAntiAlias(true);
        paint.setColor(0xFFFFFFFF);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawARGB(0, 0, 0, 0);
        canvas.drawCircle(r, r, r, paint);

        // draw bitmap
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(output, rect, rect, paint);

        // draw border
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((float) t);
        canvas.drawCircle(r, r, r, paint);

        return output;
    }

    public static Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height,
                matrix, false);
        return resizedBitmap;
    }

    public static boolean saveBitmapToFile(Bitmap bm, String path) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);

            File f = new File(path);
            f.createNewFile();
            // write the bytes in file
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            fo.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static class RoundedTransformation implements com.squareup.picasso.Transformation {

        private Context context;
        private final int radius;
        private final int margin; // dp
        private int color_id = 0;

        public RoundedTransformation(Context context, int radius, int margin, int color_id) {
            this.context = context;
            this.radius = radius;
            this.margin = margin;
            this.color_id = color_id;
        }

        @Override
        public Bitmap transform(Bitmap source) {
            // Bitmap source1 = null;
            // reference the scaled bitmap to local bitmap
            // source1 = Bitmap.createScaledBitmap(source, radius * 2, radius * 2, true);
            // recycle the original bitmap
            // source.recycle();

            int d = radius * 2;
            int r = radius;
            Bitmap output = Bitmap.createBitmap(d, d, Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            final Paint paint = new Paint();
            final Rect rect = new Rect(0, 0, d, d);

            paint.setAntiAlias(true);
            paint.setColor(0xFFFFFFFF);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawARGB(0, 0, 0, 0);
            canvas.drawCircle(r, r, r, paint);

            // draw bitmap
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            // canvas.drawBitmap(source1, rect, rect, paint);
            canvas.drawBitmap(source, rect, rect, paint);
            source.recycle();

            // draw border
            Log.d("TEST", "--- color_id: " + color_id);

            paint.setColor(context.getResources().getColor(color_id));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth((float) margin);
            canvas.drawCircle(r, r, r, paint);
            return output;
        }

        @Override
        public String key() {
            return "rounded";
        }
    }

    public static Bitmap getBitmapFromVectorDrawable(Context context, int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(context, drawableId);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = (DrawableCompat.wrap(drawable)).mutate();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }
}
