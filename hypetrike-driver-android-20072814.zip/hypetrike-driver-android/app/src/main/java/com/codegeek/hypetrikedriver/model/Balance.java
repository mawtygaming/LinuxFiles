package com.codegeek.hypetrikedriver.model;

import java.util.ArrayList;

public class Balance {

    private double currentBalance;
    private String param;
    private ArrayList<BalanceTransaction> transactions;

    public Balance(double currentBalance, String currentParam, ArrayList<BalanceTransaction> transactions) {
        this.currentBalance = currentBalance;
        this.param = currentParam;
        this.transactions = transactions;
    }

    public double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public ArrayList<BalanceTransaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(ArrayList<BalanceTransaction> transactions) {
        this.transactions = transactions;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }
}
