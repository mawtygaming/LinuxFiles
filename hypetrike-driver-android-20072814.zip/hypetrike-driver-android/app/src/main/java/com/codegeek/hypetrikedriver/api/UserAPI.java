package com.codegeek.hypetrikedriver.api;

import android.util.Log;

import com.codegeek.hypetrikedriver.model.HypeTrikeConstants;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.model.Status;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.ConnectException;
import java.net.SocketException;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UserAPI {
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static String errorMessage = "Unknown error occurred.";

    public static long register(String email, String mobile) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/registration")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("mobileNumber", mobile);
            jObject.put("email", email);
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            if (code.equalsIgnoreCase(Status.SUCCESS_REGISTRATION)) {
                return jResult.getLong("userId");
            } else if (code.equalsIgnoreCase(Status.FAIL_REGISTRATION_ALREADY_EXIST1)
                    || code.equalsIgnoreCase(Status.FAIL_REGISTRATION_ALREADY_EXIST2)) {
                errorMessage = "Mobile number already exist.";
                return -1;
            } else if (code.equalsIgnoreCase(Status.FAIL_REGISTRATION_INCORRECT_FORMAT)) {
                errorMessage = "Mobile number has incorrect format.";
                return -1;
            } else {
                errorMessage = "Unable to register, please try again later.";
                return -1;
            }
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return -1;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return -1;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return -1;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return -1;
        }
    }

    public static boolean validate(long uid, String otp) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/otp")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", uid);
            jObject.put("otp", otp);
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            if (!code.equalsIgnoreCase(Status.SUCCESS_OTP)) {
                if (code.equalsIgnoreCase(Status.FAIL_OTP_INVALID)) {
                    errorMessage = "Invalid OTP.";
                } else {
                    errorMessage = jResult.getString("statusMessage");
                }
                return false;
            }
            return true;
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return false;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return false;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return false;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return false;
        }
    }

    public static boolean login(HypeTrikePreferences pref) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/login")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", pref.getUserId());
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            if (code.equalsIgnoreCase(Status.SUCCESS_LOGIN)) {
                try {
                    JSONArray arrSMS = jResult.getJSONArray("smsGateways");
                    pref.setSMSGateways(arrSMS);
//                JSONArray arrADS = jResult.getJSONArray("adsImg");
//                pref.setAdsLinks(arrADS);
                    int interval = jResult.getInt("adsRefreshInterval");
                    pref.setAdsRefInterval(interval);
                } catch (Exception e) {
                    Log.e("TEST", "======= ERROR on parsing ads...");
                    e.printStackTrace();
                }
                return true;
            } else if (code.equalsIgnoreCase(Status.FAIL_LOGIN_INVALID_ID)) {
                errorMessage = "Invalid user id.";
            }
            return false;
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return false;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return false;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return false;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return false;
        }
    }

    public static int getAds(long uid, HypeTrikePreferences pref) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("http")
                    .host(HypeTrikeConstants.DOMAIN)
                    .port(HypeTrikeConstants.PORT)
                    .addPathSegments("hypetrike/driver/getads")
                    .build();

            Log.d("TEST", "======= url: " + url);

            JSONObject jObject = new JSONObject();
            jObject.put("userId", uid);
            Log.d("TEST", "======= params: " + jObject.toString());
            RequestBody body = RequestBody.create(JSON, jObject.toString());

            Request request = new Request.Builder()
                    .addHeader("Authorization", HypeTrikeConstants.HEADER_AUTH)
                    .url(url)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            String code = jResult.getString("statusCode");
            if (code.equalsIgnoreCase(Status.SUCCESS_GET_ADS)) {
                JSONArray arrADS = jResult.getJSONArray("adsImg");
                pref.setAdsLinks(arrADS);
                return arrADS.length();
            } else if (code.equalsIgnoreCase(Status.FAIL_GET_ADS_INVALID_UID)) {
                errorMessage = "Invalid user id.";
            }
            return 0;
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return 0;
        } catch (ConnectException ce) {
            errorMessage = "No internet connection.";
            ce.printStackTrace();
            return 0;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return 0;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return 0;
        }
    }

}
