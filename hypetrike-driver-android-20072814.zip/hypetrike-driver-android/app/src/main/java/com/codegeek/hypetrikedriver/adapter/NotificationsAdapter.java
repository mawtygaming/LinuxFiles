package com.codegeek.hypetrikedriver.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.NotificationMsg;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<NotificationMsg> notifications;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView sender, dateTime, message;

        public MyViewHolder(View view) {
            super(view);
            sender = view.findViewById(R.id.tv_sender);
            dateTime = view.findViewById(R.id.tv_date_time);
            message = view.findViewById(R.id.tv_message);
        }
    }

    public NotificationsAdapter(Context context, ArrayList<NotificationMsg> notifications) {
        this.context = context;
        this.notifications = notifications;
    }

    public void setList(ArrayList<NotificationMsg> notifications) {
        this.notifications = notifications;
        this.notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.list_item_notification, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        NotificationMsg notif = notifications.get(position);
        holder.sender.setText(notif.getSenderName().toUpperCase());
        try {
            holder.dateTime.setText(GeekUtility.changeDateFormat(notif.getDateTime(),
                    "yyyy-MM-dd HH:mm:ss",
                    "MMMM dd, yyyy, hh:mm a"));
        } catch (Exception e) {
            e.printStackTrace();
            holder.dateTime.setText(notif.getDateTime());
        }
        holder.message.setText(notif.getMessage());
    }

    @Override
    public int getItemCount() {
        return notifications.size();
    }
}
