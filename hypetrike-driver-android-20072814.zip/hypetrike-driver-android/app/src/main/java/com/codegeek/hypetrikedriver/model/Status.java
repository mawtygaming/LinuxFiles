package com.codegeek.hypetrikedriver.model;

public class Status {
    public static final String SUCCESS_REGISTRATION = "02000";
    public static final String SUCCESS_OTP = "08000";
    public static final String SUCCESS_LOGIN = "04000";
    public static final String SUCCESS_GET_TRANSACTIONS = "11000";
    public static final String SUCCESS_GET_BALANCES = "12000";
    public static final String SUCCESS_GET_NOTIFICATIONS = "14000";
    public static final String SUCCESS_GET_ADS = "16000";
    public static final String SUCCESS_BOOKING_ACCEPTANCE = "22000";
    public static final String SUCCESS_BOOKING_PICKUP = "24000";
    public static final String SUCCESS_BOOKING_COMPLETE = "25000";
    public static final String SUCCESS_BOOKING_CANCEL = "31000";
    public static final String SUCCESS_BOOKING_INQUIRE = "35000";

    public static final String FAIL_REGISTRATION_ALREADY_EXIST1 = "01001";
    public static final String FAIL_REGISTRATION_ALREADY_EXIST2 = "02001";
    public static final String FAIL_REGISTRATION_INCORRECT_FORMAT = "02002";
    public static final String FAIL_LOGIN_INVALID_ID = "04001";
    public static final String FAIL_OTP_INVALID = "08002";
    public static final String FAIL_GET_TRANSACTIONS_INVALID_UID = "11001";
    public static final String FAIL_GET_BALANCES_INVALID_UID = "12001";
    public static final String FAIL_GET_NOTIFICATIONS_INVALID_UID = "14001";
    public static final String FAIL_GET_ADS_INVALID_UID = "16001";
    public static final String FAIL_BOOKING_INVALID_BOOKING_ID = "22001";
    public static final String FAIL_BOOKING_ACCEPTED_BY_OTHER_DRIVER1 = "22002";
    public static final String FAIL_BOOKING_CANCELLED_BY_RIDER = "22003";
    public static final String FAIL_BOOKING_TIMEOUT_BY_RIDER = "22004";
    public static final String FAIL_BOOKING_ACCEPTED_BY_OTHER_DRIVER2 = "28001";
    public static final String FAIL_BOOKING_CANCELLED_BY_RIDER2 = "28002";
    public static final String FAIL_BOOKING_TIMEOUT= "28003";
    public static final String FAIL_BOOKING_CANCEL_INVALID_BID = "31001";
    public static final String FAIL_BOOKING_CANCEL_INVALID_GEN_ERROR = "31999";
    public static final String FAIL_BOOKING_INQUIRE_INVALID_BID = "35001";
    public static final String FAIL_BOOKING_INQUIRE_GEN_ERROR = "35999";
}
