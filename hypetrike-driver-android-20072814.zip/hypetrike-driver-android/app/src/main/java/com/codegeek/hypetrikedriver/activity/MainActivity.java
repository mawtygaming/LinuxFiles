package com.codegeek.hypetrikedriver.activity;

import android.Manifest;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codegeek.hypetrikedriver.BuildConfig;
import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.adapter.BookingInvitesAdapter;
import com.codegeek.hypetrikedriver.adapter.MessagesAdapter;
import com.codegeek.hypetrikedriver.api.UserAPI;
import com.codegeek.hypetrikedriver.fragment.BalancesFragment;
import com.codegeek.hypetrikedriver.fragment.MapFragment;
import com.codegeek.hypetrikedriver.fragment.NotificationsFragment;
import com.codegeek.hypetrikedriver.fragment.TransactionsFragment;
import com.codegeek.hypetrikedriver.model.Booking;
import com.codegeek.hypetrikedriver.model.BookingMessage;
import com.codegeek.hypetrikedriver.model.Coordinate;
import com.codegeek.hypetrikedriver.model.HypeTrikeConstants;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.model.NotificationMsg;
import com.codegeek.hypetrikedriver.model.Price;
import com.codegeek.hypetrikedriver.model.Status;
import com.codegeek.hypetrikedriver.util.GeekFont;
import com.codegeek.hypetrikedriver.util.GeekUtility;
import com.codegeek.hypetrikedriver.util.UpdateLocationService;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import io.socket.engineio.client.EngineIOException;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static final int PERMISSION_ALL = 101;
    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
//            Manifest.permission.READ_PHONE_STATE,
//            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
//            Manifest.permission.READ_SMS
    };

    private HypeTrikePreferences mPref;
    private Fragment mCurrFragment;
    private DrawerLayout mDrawer;
    private ImageView mAdsView;
    private AlertDialog mExitDialog;
    private AlertDialog mLogoutDialog;
    private AlertDialog mPermissionErrorDialog;
    private AlertDialog mGPSErrorDialog;
    private AlertDialog mErrorDialog;
    private AlertDialog mPickUpConfirmationDialog;
    private AlertDialog mDropOffConfirmationDialog;
    private AlertDialog mCancelConfirmationDialog;
    private AlertDialog mReportDialog;
    private AlertDialog mMessageDialog;
    private AlertDialog mNotifDialog;
    private RecyclerView mRecyclerView;

    private AlertDialog mBookingInviteDialog;
    private TextView mBookingTitle;
    private TextView mNoReqs;
    private RecyclerView mRvBookingInvites;
    private BookingInvitesAdapter mBookingInvitesAdapter;
    private ArrayList<Booking> mBookingInvites;
    private MessagesAdapter mMessagesAdapter;
    private ArrayList<BookingMessage> mBookingMessages;

    private Socket mSocket;
    private String mToastMessage = "";
    private String mErrorTitle = "Error";
    private String mErrorMessage = "Unknown server error.";
    private Double mCurrLat;
    private Double mCurrLng;
    private Booking mCurrBooking;
    private ArrayList<NotificationMsg> mNotifs;
    private NotificationCompat.Builder mNotifBuilder;

    private int tempCtr;

    private static final int MSG_SUCCESS_BOOKING = 0;
    private static final int MSG_TOAST = 1;
    private static final int MSG_ERROR_DIALOG = 2;
    private static final int MSG_HIDE_BOOKING_DIALOG = 4;
    private static final int MSG_UPDATE_BOOKING_LIST = 5;
    private static final int MSG_UPDATE_BOOKING_LIST_ON_BG = 6;
    private static final int MSG_GO_HOME = 7;
    private static final int MSG_SETUP_MSG_DIALOG = 8;
    private static final int MSG_ADD_NEW_MSG = 9;
    private static final int MSG_SHOW_NOTIF = 10;
    private static final int MSG_SHOW_ADS = 11;

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_SUCCESS_BOOKING:
                    GeekUtility.hideProgressDialog(MainActivity.this);
                    GeekUtility.showToast(MainActivity.this, "Booking success!");
                    break;
                case MSG_TOAST:
                    GeekUtility.hideProgressDialog(MainActivity.this);
                    GeekUtility.showToast(MainActivity.this, mToastMessage);
                    break;
                case MSG_ERROR_DIALOG:
                    GeekUtility.hideProgressDialog(MainActivity.this);
                    mErrorDialog.setTitle(mErrorTitle);
                    mErrorDialog.setMessage(mErrorMessage);
                    mErrorDialog.setButton(Dialog.BUTTON_POSITIVE, "Dismiss", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            mErrorDialog.dismiss();
                        }
                    });
                    mErrorDialog.show();
                    break;
                case MSG_HIDE_BOOKING_DIALOG:
                    GeekUtility.hideProgressDialog(MainActivity.this);
                    if (mBookingInviteDialog != null && mBookingInviteDialog.isShowing()) {
                        mBookingInviteDialog.hide();
//                        mCurrBooking = null;
//                        ((MapFragment) mCurrFragment).setBooking(null);
                    }
                    mBookingInviteDialog = null;
                    break;
                case MSG_UPDATE_BOOKING_LIST:
                    if (mBookingInviteDialog != null) {
                        mBookingInviteDialog.show();
                        mBookingInvitesAdapter.setList(mBookingInvites);
                        mBookingTitle.setText("REQUESTS (" + mBookingInvitesAdapter.getItemCount() + ")");
                        if (mBookingInvitesAdapter.getItemCount() <= 0) {
                            mRvBookingInvites.setVisibility(View.GONE);
                            mNoReqs.setVisibility(View.VISIBLE);
                        } else {
                            mRvBookingInvites.setVisibility(View.VISIBLE);
                            mNoReqs.setVisibility(View.GONE);
                        }
                    }
                    break;
                case MSG_UPDATE_BOOKING_LIST_ON_BG:
                    if (mBookingInvitesAdapter != null && mBookingInvites != null && mRvBookingInvites != null) {
                        mBookingInvitesAdapter.setList(mBookingInvites);
                        if (mBookingTitle != null)
                            mBookingTitle.setText("REQUESTS (" + mBookingInvitesAdapter.getItemCount() + ")");
                        if (mBookingInvitesAdapter.getItemCount() <= 0) {
                            mRvBookingInvites.setVisibility(View.GONE);
                            mNoReqs.setVisibility(View.VISIBLE);
                        } else {
                            mRvBookingInvites.setVisibility(View.VISIBLE);
                            mNoReqs.setVisibility(View.GONE);
                        }
                    }
                    break;
                case MSG_GO_HOME:
                    goHome();
                    break;
                case MSG_SETUP_MSG_DIALOG:
                    setupMessageDialog();
                    break;
                case MSG_ADD_NEW_MSG:
                    // GeekUtility.hideProgressDialog(MainActivity.this);
                    mMessagesAdapter.setList(mBookingMessages);
                    if (mBookingMessages.size() > 0) {
                        mRecyclerView.smoothScrollToPosition(mBookingMessages.size() - 1);
                    }
                    if (mMessageDialog != null) {
                        if (!mMessageDialog.isShowing())
                            mMessageDialog.show();
                    } else {
                        setupMessageDialog();
                        mMessageDialog.show();
                    }
                    break;
                case MSG_SHOW_NOTIF:
                    if (mNotifs != null) {
                        String message = "Sender: " + mNotifs.get(0).getSenderName()
                                + "\nDate: " + mNotifs.get(0).getDateTime()
                                + "\n\nMessage: " + mNotifs.get(0).getMessage();
                        for (int i = 1; i < mNotifs.size(); i++) {
                            String str = "\n\n\nSender: " + mNotifs.get(i).getSenderName()
                                    + "\nDate: " + mNotifs.get(i).getDateTime()
                                    + "\nMessage: " + mNotifs.get(i).getMessage();
                            message = message + str;
                        }
                        mNotifDialog.setMessage(message);
                        mNotifDialog.show();
                    }
                    break;
                case MSG_SHOW_ADS:
                    GeekUtility.hideProgressDialog(MainActivity.this);
                    GeekUtility.showToast(MainActivity.this, "Loading ads (" + mPref.getAdsLinks().size() + ")...");
                    mAdsView.setVisibility(View.VISIBLE);
                    adsHandler.post(adsRunnable);
                    break;
            }
        }
    };

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Coordinate coor = (Coordinate) bundle.getSerializable("coordinates");
//                Toast.makeText(getApplicationContext(),
//                        "LAT: " + coor.getLat()
//                                + " LNG: " + coor.getLng(),
//                        Toast.LENGTH_LONG).show();
                mCurrLat = coor.getLat();
                mCurrLng = coor.getLng();
                int resultCode = bundle.getInt("result");
                Log.d("TEST", "***** Fragment: " + mCurrFragment.getClass().toString());
                if (resultCode == RESULT_OK && mCurrFragment.getClass().equals(MapFragment.class)) {
                    Log.d("TEST", "***** updating location on map!!!!");
                    ((MapFragment) mCurrFragment).updateLocation(coor);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupData();
        setupViews();

        // Check connection first
        if (!GeekUtility.isNetworkAvailable(this)) {
            mErrorDialog.setTitle("Connection Error");
            mErrorDialog.setMessage("Internet connection not found. Internet is required for this" +
                    " app. Please check your network settings");
            mErrorDialog.setButton(Dialog.BUTTON_POSITIVE, "Close App", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.finish();
                }
            });
            mErrorDialog.show();
        } else {
            setupPermissions();
            setupSocket();
            // setupAds();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mReceiver, new IntentFilter(UpdateLocationService.ACTION_UPDATE_LOCATION));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mReceiver);
    }

    private void setupData() {
        mPref = new HypeTrikePreferences(this);
        mBookingInvites = new ArrayList<>();
        mBookingInvitesAdapter = new BookingInvitesAdapter(this, mBookingInvites);
        mBookingMessages = new ArrayList<>();
        mMessagesAdapter = new MessagesAdapter(this, mBookingMessages);
        GeekUtility.initToast(this);
    }

    private void setupViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDrawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        mDrawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navView = mDrawer.findViewById(R.id.nav_view);
        View headerView = navView.getHeaderView(0);
        TextView navName = headerView.findViewById(R.id.tv_header_name);
        TextView navMobile = headerView.findViewById(R.id.tv_header_mobile);
        if (mPref.getFirstName() != null && mPref.getLastName() != null) {
            navName.setText(mPref.getFirstName() + " " + mPref.getLastName());
        } else {
            navName.setText(mPref.getEmail());
        }
        navMobile.setText(mPref.getMobile());

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Navigation buttons
        Menu m = navigationView.getMenu();
        for (int i = 0; i < m.size(); i++) {
            MenuItem mi = m.getItem(i);
            SubMenu subMenu = mi.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int j = 0; j < subMenu.size(); j++) {
                    MenuItem subMenuItem = subMenu.getItem(j);
                    String title = subMenuItem.getTitle().toString().toUpperCase();
                    subMenuItem.setTitle(GeekFont.applyFont(title, GeekFont.getHeaderTypeFace(this)));
                }
            }
            String title = mi.getTitle().toString().toUpperCase();
            mi.setTitle(GeekFont.applyFont(title, GeekFont.getHeaderTypeFace(this)));
        }

        mAdsView = findViewById(R.id.img_ads);
        mAdsView.setVisibility(View.GONE);

        TextView version = findViewById(R.id.tv_version);
        version.setText("Version " + BuildConfig.VERSION_NAME + " | Build " + BuildConfig.VERSION_CODE);

        setupExitDialog();
        setupLogoutDialog();
        setupPermissionErrorDialog();
        setupErrorDialog();
        setupGPSErrorDialog();
        setupPickUpConfirmationDialog();
        setupDropOffConfirmationDialog();
        setupCancelConfirmation();
        setupReportDialog();
        setupNotifDialog();
        setupNotification();
    }

    private int adsIndex = 0;
    private Handler adsHandler = new Handler();
    private Runnable adsRunnable = new Runnable() {
        @Override
        public void run() {
            if (mPref.getAdsLinks().size() == 0 || mPref.getAdsLinks().size() < adsIndex) {
                return;
            }
//
//            mPref.getAdsLinks().get(adsIndex));
            Picasso.with(MainActivity.this).load(mPref.getAdsLinks().get(adsIndex))
                    .resize(GeekUtility.getScreenWidth(MainActivity.this),
                            GeekUtility.getScreenWidth(MainActivity.this) / 5)
                    .into(mAdsView);
            if (adsIndex < mPref.getAdsLinks().size() - 1)
                adsIndex++;
            else
                adsIndex = 0;
            adsHandler.postDelayed(adsRunnable, mPref.getAdsRefInterval());
        }
    };

    private void setupPermissions() {
        boolean hasPermissions = true;
        for (String p : PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions) {
            ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, PERMISSION_ALL);
        } else {
            replaceFragment(MapFragment.newInstance(), R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
        }

        // Check GPS availability
        LocationManager locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locManager != null && !locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            mGPSErrorDialog.show();
        }
    }

    private void setupSocket() {
        try {
            tempCtr = 1;
            IO.Options opts = new IO.Options();
            opts.forceNew = true;
            mSocket = IO.socket(HypeTrikeConstants.SOCKET_URL, opts);
            mSocket.on(Socket.EVENT_CONNECT, onConnect)
                    .on(Socket.EVENT_DISCONNECT, onDisconnect)
                    .on(Socket.EVENT_ERROR, onError)
                    .on("booking.invite", onBookingInvite)
                    .on("booking.notify.driver", onNotifyDriver)
                    .on("booking.message.in", onMessageReceived)
                    .on("user.notification.in", onNotificationReceived);
            mSocket.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupAds() {
        new Thread() {
            public void run() {
                int ads = UserAPI.getAds(mPref.getUserId(), mPref);
                if (ads > 0) {
                    Log.d("TEST", "+++++++++++ ads.size(): " + mPref.getAdsLinks().size());
                    mHandler.sendEmptyMessage(MSG_SHOW_ADS);
                } else {
                    Log.e("TEST", "+++++++++++ NO ADS!!!");
                }
            }
        }.start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ALL:
                boolean hasPermissionDenied = false;
                for (int i = 0; i < grantResults.length; i++) {
                    // If request is cancelled, the result arrays are empty.
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        // permission was granted, yay!
                        Log.d("TEST", "--- permission GRANTED on " + permissions[i]);
                        hasPermissionDenied = false;
                        replaceFragment(MapFragment.newInstance());
                    } else {
                        // permission denied, boo! show error dialog then exit.
                        Log.d("TEST", "--- permission DENIED on " + permissions[i]);
                        hasPermissionDenied = true;
                    }
                }
                if (hasPermissionDenied) {
                    mPermissionErrorDialog.show();
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        Log.d("TEST", ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> onBackPressed()");
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            FragmentManager fm = getSupportFragmentManager();
            Log.d("TEST", "--- stack: " + fm.getBackStackEntryCount());
            if (fm.getBackStackEntryCount() > 1) {
                fm.popBackStack();
            } else {
                mExitDialog.show();
            }
        }
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
//        return true;
//    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            Log.d("TEST", "--- completing all bookings...");
//            tempCtr = 1;
//            removeAllBooking();
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                goHome();
                break;
            case R.id.nav_balance:
                replaceFragment(BalancesFragment.newInstance(), R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
                break;
            case R.id.nav_history:
                replaceFragment(TransactionsFragment.newInstance(), R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
                break;
            case R.id.nav_report:
                mReportDialog.show();
                break;
            case R.id.nav_notifications:
                replaceFragment(NotificationsFragment.newInstance(), R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
                break;
            case R.id.nav_logout:
                mLogoutDialog.show();
                break;
        }

        mDrawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void setupExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Exit");
        builder.setMessage("Do you want to exit TRIKE.PH?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mExitDialog.dismiss();
            }
        });
        mExitDialog = builder.create();
    }

    private void setupLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Logout");
        builder.setMessage("Do you want to logout from TRIKE.PH?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                logout();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mLogoutDialog.dismiss();
            }
        });
        mLogoutDialog = builder.create();
    }

    private void setupPermissionErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Setup Error");
        builder.setMessage("Permissions are required to use this app. Review permissions again?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                setupPermissions();
            }
        });
        builder.setNegativeButton("No, close app", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        mPermissionErrorDialog = builder.create();
    }

    private void setupErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Error");
        builder.setMessage("Unknown server error.");
        builder.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        mErrorDialog = builder.create();
    }

    private void setupGPSErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("GPS Error");
        builder.setMessage("Location not found, kindly turn on your GPS settings.");
        builder.setNegativeButton("Close app", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        mGPSErrorDialog = builder.create();
    }

    private void setupBookingInviteDialog() {
        View view = this.getLayoutInflater().inflate(R.layout.dialog_booking_received, null);
        mRvBookingInvites = view.findViewById(R.id.rv_transaction_list);
        mRvBookingInvites.setAdapter(mBookingInvitesAdapter);
        mRvBookingInvites.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        mBookingTitle = view.findViewById(R.id.tv_booking_title);
        mBookingTitle.setText("REQUESTS (" + mBookingInvitesAdapter.getItemCount() + ")");
        mBookingTitle.setTypeface(GeekFont.getBoldTypeFace(this));

        mNoReqs = view.findViewById(R.id.tv_no_requests);
        mNoReqs.setTypeface(GeekFont.getHeaderTypeFace(this));

        ImageView close = view.findViewById(R.id.img_close_dialog);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBookingInviteDialog.dismiss();
            }
        });

        if (mBookingInvitesAdapter.getItemCount() <= 0) {
            mRvBookingInvites.setVisibility(View.GONE);
            mNoReqs.setVisibility(View.VISIBLE);
        } else {
            mRvBookingInvites.setVisibility(View.VISIBLE);
            mNoReqs.setVisibility(View.GONE);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setView(view);
        mBookingInviteDialog = builder.create();
    }

    private void setupPickUpConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Pick Up");
        builder.setMessage("Pick up rider and start the trip?");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mPickUpConfirmationDialog.dismiss();
            }
        });
        builder.setPositiveButton("Start Trip", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                bookingPickup(mPref.getUserId(), mCurrBooking.getId());
            }
        });
        mPickUpConfirmationDialog = builder.create();
    }

    private void setupDropOffConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Drop Off");
        builder.setMessage("Drop off rider and complete the trip?");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mDropOffConfirmationDialog.dismiss();
            }
        });
        builder.setPositiveButton("Complete Trip", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                bookingComplete(mPref.getUserId(), mCurrBooking.getId());
            }
        });
        mDropOffConfirmationDialog = builder.create();
    }

    private void setupCancelConfirmation() {
        View view = this.getLayoutInflater().inflate(R.layout.dialog_cancel, null);
        final EditText message = view.findViewById(R.id.et_message);
        TextView submit = view.findViewById(R.id.tv_submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = message.getText().toString();
                if (msg.isEmpty()) {
                    GeekUtility.showToast(MainActivity.this, "Message cannot be empty!");
                } else {
                    mCancelConfirmationDialog.dismiss();
                    bookingCancel(mPref.getUserId(), mCurrBooking.getId(), message.getText().toString());
                }
            }
        });
        TextView back = view.findViewById(R.id.tv_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCancelConfirmationDialog.dismiss();
            }
        });

        ImageView close = view.findViewById(R.id.img_close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCancelConfirmationDialog.dismiss();
            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setView(view);
        mCancelConfirmationDialog = builder.create();
    }

    private void setupReportDialog() {
        View view = this.getLayoutInflater().inflate(R.layout.dialog_report, null);
        final EditText message = view.findViewById(R.id.et_message);
        TextView submit = view.findViewById(R.id.tv_submit_report);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = message.getText().toString();
                if (msg.isEmpty()) {
                    GeekUtility.showToast(MainActivity.this, "Message cannot be empty!");
                } else {
                    mReportDialog.dismiss();
                    sendReport(mPref.getUserId(), message.getText().toString());
                }
            }
        });
        ImageView close = view.findViewById(R.id.img_close_report);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mReportDialog.dismiss();
            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setView(view);
        mReportDialog = builder.create();
    }

    private void setupMessageDialog() {
        View view = this.getLayoutInflater().inflate(R.layout.dialog_messages, null);
        TextView rider = view.findViewById(R.id.tv_rider_name);
        TextView bid = view.findViewById(R.id.tv_bid);
        rider.setText(mCurrBooking.getRiderFullName());
        bid.setText("Booking ID: " + mCurrBooking.getId());

        mRecyclerView = view.findViewById(R.id.rv_messages);
        mRecyclerView.setAdapter(mMessagesAdapter);

        final LinearLayoutManager lm = new LinearLayoutManager(MainActivity.this);
        mRecyclerView.setLayoutManager(lm);

        final EditText message = view.findViewById(R.id.et_message);
        Button send = view.findViewById(R.id.btn_send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = message.getText().toString();
                if (msg.isEmpty()) {
                    GeekUtility.showToast(MainActivity.this, "Message cannot be empty!");
                } else {
                    // mMessageDialog.dismiss();
                    sendMessage(mPref.getUserId(), mCurrBooking.getId(), message.getText().toString());
                    message.setText("");
                }
            }
        });
        ImageView close = view.findViewById(R.id.img_close_messages);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMessageDialog.dismiss();
            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setView(view);
        mMessageDialog = builder.create();
    }

    public void showMessageDialog() {
        if (!mMessageDialog.isShowing()) {
            mMessageDialog.show();
            if (mBookingMessages.size() > 0)
                mRecyclerView.smoothScrollToPosition(mBookingMessages.size() - 1);
        }
    }

    private void setupNotifDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Notification");
        builder.setMessage("Admin notification");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mNotifDialog.dismiss();
            }
        });
        mNotifDialog = builder.create();
    }

    public void replaceFragment(Fragment fragment) {
        Log.i("TEST", ">>>>>>> New Fragment: " + fragment.getClass().toString());
        mCurrFragment = fragment;
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_from_right, R.anim.slide_out_to_left,
                R.anim.slide_in_from_left, R.anim.slide_out_to_right);
        transaction.replace(R.id.container, fragment).commitAllowingStateLoss();
        transaction.addToBackStack(fragment.getClass().toString());
        // refresh ads
        setupAds();
    }

    public void replaceFragment(Fragment fragment, int enter, int exit, int popEnter, int popExit) {
        Log.i("TEST", ">>>>>>> New Fragment: " + fragment.getClass().toString());
        mCurrFragment = fragment;
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setCustomAnimations(enter, exit, popEnter, popExit);
        transaction.replace(R.id.container, fragment).commitAllowingStateLoss();
        transaction.addToBackStack(fragment.getClass().toString());
        // refresh ads
        setupAds();
    }

    private void goHome() {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        replaceFragment(MapFragment.newInstance(), R.anim.fadein, R.anim.fadeout, R.anim.fadein, R.anim.fadeout);
    }

    private void logout() {
        mPref.clear();
        if (mSocket != null) {
            mSocket.disconnect();
        }
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        startActivity(intent);
    }

    public void showPickUpConfirmation() {
        if (mPickUpConfirmationDialog != null && !mPickUpConfirmationDialog.isShowing()) {
            mPickUpConfirmationDialog.show();
        }
    }

    public void showDropOffConfirmation() {
        if (mDropOffConfirmationDialog != null && !mDropOffConfirmationDialog.isShowing()) {
            mDropOffConfirmationDialog.setMessage("Drop off rider and complete the trip?" +
                    "\n\n" + GeekFont.applyFont(String.format("Fare: P%.2f", mCurrBooking.getPrice().getTotal()),
                    GeekFont.getHeaderTypeFace(this)));
            mDropOffConfirmationDialog.show();
        }
    }

    public void showCancelConfirmation() {
        if (mCancelConfirmationDialog != null && !mCancelConfirmationDialog.isShowing()) {
            mCancelConfirmationDialog.show();
        }
    }

    // ========== SOCKET EMITTERS ==========

    private void connectionUpdate(long uid) {
        Log.d("TEST", "---- connectionUpdate()...");

        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                mSocket.emit("connection.update", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        JSONObject obj = (JSONObject) args[0];
                        Log.d("TEST", "---- connectionUpdate().ack: " + obj.toString());
                    }
                });
            } catch (Exception e) {
                Log.d("TEST", "---- ERROR on connectionUpdate()");
                e.printStackTrace();
            }
        }
    }

    public void bookingAccept(Booking booking) {
        mCurrBooking = booking;
        mPref.setCurrBID(booking.getId());
        mBookingInviteDialog.dismiss();
        bookingAccept(mPref.getUserId(), booking.getId(), new LatLng(mCurrLat, mCurrLng));
    }

    public void bookingAccept(long uid, final long bid, final LatLng myLoc) {
        Log.d("TEST", "---- bookingAccept()...");
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                JSONObject location = new JSONObject();
                location.put("lat", myLoc.latitude);
                location.put("lng", myLoc.longitude);
                data.put("location", location);
                mSocket.emit("booking.accept", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        JSONObject obj = (JSONObject) args[0];
                        Log.d("TEST", "---- bookingAccept().ack: " + obj.toString());
                        try {
                            // Set Map Fragment booking
                            ((MapFragment) mCurrFragment).setBooking(mCurrBooking);
                            // remove booking from list
                            removeBooking(bid);
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase(Status.SUCCESS_BOOKING_ACCEPTANCE)) {
                                // create pick up route
                                ((MapFragment) mCurrFragment).processPickUpRoute();
                                // setup messaging
                                mHandler.sendEmptyMessage(MSG_SETUP_MSG_DIALOG);
                                // UpdateLocationService.startUpdateLocation(MainActivity.this, mCurrBooking);
                            } else {
                                Log.e("TEST", "---- booking accept error, code: " + code);
                                if (code.equalsIgnoreCase(Status.FAIL_BOOKING_INVALID_BOOKING_ID)) {
                                    mErrorTitle = "Fail";
                                    mErrorMessage = "Invalid booking ID.";
                                } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_ACCEPTED_BY_OTHER_DRIVER1)) {
                                    mErrorTitle = "Fail";
                                    mErrorMessage = "Booking transaction was accepted by another driver.";
                                } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_CANCELLED_BY_RIDER)) {
                                    mErrorTitle = "Cancelled";
                                    mErrorMessage = "Booking transaction cancelled by the rider.";
                                } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_TIMEOUT_BY_RIDER)) {
                                    mErrorTitle = "Timeout";
                                    mErrorMessage = "Booking transaction timed out by the rider.";
                                }
                                // mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
                                mToastMessage = mErrorMessage;
                                mHandler.sendEmptyMessage(MSG_TOAST);
                                resetLocService();
                            }
                            UpdateLocationService.startUpdateLocation(MainActivity.this, mCurrBooking);
                        } catch (Exception e) {
                            Log.e("TEST", "---- booking accept error: " + e.getMessage());
                            resetLocService();
                            UpdateLocationService.startUpdateLocation(MainActivity.this, mCurrBooking);
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                Log.d("TEST", "---- ERROR on bookingAccept()");
                resetLocService();
                e.printStackTrace();
            }
        }
    }

    public void bookingPickup(long uid, long bid) {
        Log.d("TEST", "---- bookingPickup()...");
        GeekUtility.showProgressDialog(this, "Updating trip...");
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                mSocket.emit("booking.pickup", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        JSONObject obj = (JSONObject) args[0];
                        Log.d("TEST", "---- bookingPickup().ack: " + obj.toString());
                        try {
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase(Status.SUCCESS_BOOKING_PICKUP)) {
                                // create drop off route
                                ((MapFragment) mCurrFragment).processDropOffRoute();
                            } else {
                                Log.e("TEST", "---- booking pickup error, code: " + code);
                            }
                        } catch (Exception e) {
                            Log.e("TEST", "---- ERROR[2] on bookingPickup(): " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR[1] on bookingPickup(), " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void bookingComplete(long uid, long bid) {
        GeekUtility.showProgressDialog(this, "Completing trip...");
        Log.d("TEST", "---- bookingComplete()...");
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                mSocket.emit("booking.complete", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        JSONObject obj = (JSONObject) args[0];
                        Log.d("TEST", "---- bookingComplete().ack: " + obj.toString());
                        try {
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase(Status.SUCCESS_BOOKING_COMPLETE)) {
                                // reset messages
                                mBookingMessages = new ArrayList<>();
                                mMessagesAdapter.setList(mBookingMessages);
                                // reset top and bot nav back to PICK UP mode
                                ((MapFragment) mCurrFragment).resetNav();
                                // show current location
                            } else {
                                Log.e("TEST", "---- booking complete error, code: " + code);
                            }
                        } catch (Exception e) {
                            Log.e("TEST", "---- ERROR[2] on bookingComplete(): " + e.getMessage());
                            e.printStackTrace();
                        }

                        resetLocService();
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR[1] on bookingComplete(): " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public void bookingCancel(long uid, long bid, String reason) {
        GeekUtility.showProgressDialog(this, "Cancelling booking...");
        Log.d("TEST", "---- bookingCancel()...");
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                data.put("reason", reason);
                mSocket.emit("booking.cancel.driver", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        JSONObject obj = (JSONObject) args[0];
                        Log.d("TEST", "---- bookingCancel().ack: " + obj.toString());
                        try {
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase(Status.SUCCESS_BOOKING_CANCEL)) {
                                // reset messages
                                mBookingMessages = new ArrayList<>();
                                mMessagesAdapter.setList(mBookingMessages);
                                // reset top and bot nav back to PICK UP mode
                                ((MapFragment) mCurrFragment).resetNav();
                                // show current location
                            } else {
                                Log.e("TEST", "---- booking cancel error, code: " + code);
                            }
                        } catch (Exception e) {
                            Log.e("TEST", "---- ERROR[2] on bookingCancel(): " + e.getMessage());
                            e.printStackTrace();
                        }

                        resetLocService();
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR[1] on bookingComplete(): " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public void bookingInquire(long uid, long bid) {
        Log.d("TEST", "---- bookingInquire()... connected: " + mSocket.connected());
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            // mHandler.sendEmptyMessage(MSG_HIDE_WARNING);
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                mSocket.emit("booking.inquire.driver", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        try {
                            JSONObject obj = (JSONObject) args[0];
                            Log.d("TEST", "---- bookingInquire().ack: " + obj.toString());
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase(Status.SUCCESS_BOOKING_INQUIRE)) {
                                // Success
                                long bookingId = obj.getLong("bookingId");
                                int bookingStatus = obj.getInt("bookingStatus");
                                // 1 - booking open
                                // 2 - booking accepted
                                // 3 - in transit to destination
                                // 4 - arrived at destination
                                // 5 - cancelled by rider
                                // 6 - cancelled by driver
                                // 7 - no available driver
                                // 8 - booking timed out
                                // 9 - completed with rating

                                JSONObject jPickup = obj.getJSONObject("pickup");
                                JSONObject jDropoff = obj.getJSONObject("dropoff");
                                String msg = obj.getString("msg");
                                int distance = obj.getInt("distance");
                                int duration = obj.getInt("duration");

                                String pickupName = "";
                                try {
                                    pickupName = obj.getString("pickupName");
                                } catch (Exception e) {
                                    Log.e("TEST", "---- bookingInquire() ERROR: unable to get pickupName");
                                    e.printStackTrace();
                                }
                                String dropoffName = "";
                                try {
                                    dropoffName = obj.getString("dropoffName");
                                } catch (Exception e) {
                                    Log.e("TEST", "---- bookingInquire() ERROR: unable to get dropoffName");
                                    e.printStackTrace();
                                }

                                Coordinate pickup = new Coordinate(jPickup.getDouble("lat"), jPickup.getDouble("lng"));
                                Coordinate dropoff = new Coordinate(jDropoff.getDouble("lat"), jDropoff.getDouble("lng"));

                                JSONObject jPrice = obj.getJSONObject("price");
                                double standard = jPrice.getDouble("standard");
                                double succeeding = jPrice.getDouble("succeeding");
                                double premium = jPrice.getDouble("premium");
                                double total = jPrice.getDouble("total");
                                double promo = jPrice.getDouble("promo");
                                Price price = new Price(standard, succeeding, premium, total, promo);

                                Booking booking = new Booking();
                                booking.setId(bookingId);
                                booking.setPickup(pickup);
                                booking.setDropoff(dropoff);
                                booking.setPickupName(pickupName);
                                booking.setDropoffName(dropoffName);
                                booking.setDistance(distance);
                                booking.setDuration(duration);
                                booking.setPrice(price);
                                booking.setMsg(msg);

                                try {
                                    booking.setRiderFullName(obj.getString("riderFullname"));
                                } catch (Exception e) {
                                    Log.e("TEST", "---- booking.invite: riderFullname PARSE ERROR");
                                    e.printStackTrace();
                                    booking.setRiderFullName("HypeTrike Rider");
                                }

                                mCurrBooking = booking;

                                switch (bookingStatus) {
                                    case 1:
                                        Log.d("TEST", "---- bookingInquire()... booking open");
                                        break;
                                    case 2:
                                        Log.d("TEST", "---- bookingInquire()... booking accepted");
                                        // create pick up route
                                        ((MapFragment) mCurrFragment).setBooking(booking);
                                        ((MapFragment) mCurrFragment).processPickUpRoute();
                                        // setup messaging
                                        mHandler.sendEmptyMessage(MSG_SETUP_MSG_DIALOG);
                                        break;
                                    case 3:
                                        Log.d("TEST", "---- bookingInquire()... in transit to destination");
                                        // create drop off route
                                        ((MapFragment) mCurrFragment).setBooking(booking);
                                        ((MapFragment) mCurrFragment).processDropOffRoute();
                                        // setup messaging
                                        mHandler.sendEmptyMessage(MSG_SETUP_MSG_DIALOG);
                                        break;
                                    case 4:
                                        Log.d("TEST", "---- bookingInquire()... arrived at destination");
                                        mCurrBooking = null;
                                        break;
                                    case 5:
                                        Log.d("TEST", "---- bookingInquire()... cancelled by rider");
                                        mCurrBooking = null;
                                        break;
                                    case 6:
                                        Log.d("TEST", "---- bookingInquire()... cancelled by driver");
                                        mCurrBooking = null;
                                        break;
                                    case 7:
                                        Log.d("TEST", "---- bookingInquire()... no available driver");
                                        mCurrBooking = null;
                                        break;
                                    case 8:
                                        Log.d("TEST", "---- bookingInquire()... booking timed out");
                                        mCurrBooking = null;
                                        break;
                                    case 9:
                                        Log.d("TEST", "---- bookingInquire()... booking completed with rating");
                                        mCurrBooking = null;
                                        break;
                                }

                                mPref.setCurrBID(mCurrBooking == null ? 0 : mCurrBooking.getId());
                                // UpdateLocationService.startUpdateLocation(MainActivity.this, mCurrBooking);

                            } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_INQUIRE_INVALID_BID)) {
                                Log.e("TEST", "---- bookingInquire()... INVALID BOOKING ID");
                            } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_INQUIRE_GEN_ERROR)) {
                                Log.e("TEST", "---- bookingInquire()... GENERIC ERROR");
                            }
                            UpdateLocationService.startUpdateLocation(MainActivity.this, mCurrBooking);
                        } catch (Exception e) {
                            Log.e("TEST", "---- bookingInquire() error: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR on bookingInquire()");
                e.printStackTrace();
            }
        }
    }

    private void removeAllBooking() {
        GeekUtility.showProgressDialog(this, "Clearing all bookings...");
        try {
            JSONObject data = new JSONObject();
            data.put("userId", mPref.getUserId());
            data.put("bookingId", tempCtr);
            mSocket.emit("booking.complete", data, new Ack() {
                @Override
                public void call(Object... args) {
                    JSONObject obj = (JSONObject) args[0];
                    try {
                        if (obj.getString("statusCode").equalsIgnoreCase("25000")) {
                            tempCtr++;
                            removeAllBooking();
                        } else {
                            mToastMessage = "All bookings cleared!";
                            mHandler.sendEmptyMessage(MSG_TOAST);
                        }
                    } catch (Exception e) {
                        mToastMessage = "Unable to clear all bookings";
                        mHandler.sendEmptyMessage(MSG_TOAST);
                        e.printStackTrace();
                    }
                }
            });
        } catch (Exception e) {
            Log.d("TEST", "---- ERROR on removeAllBooking()");
            e.printStackTrace();
        }
    }

    public void sendReport(long uid, String message) {
        GeekUtility.showProgressDialog(this, "Sending report...");
        Log.d("TEST", "---- sendReport()... connected: " + mSocket.connected());
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("message", message);
                mSocket.emit("user.report.out", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        try {
                            JSONObject obj = (JSONObject) args[0];
                            Log.d("TEST", "---- sendReport().ack: " + obj.toString());
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase("36000")) {
                                // Success, update msgs
                                Log.d("TEST", "---- sendReport() SUCCESS");
                                mToastMessage = "Report sent!";
                                mHandler.sendEmptyMessage(MSG_TOAST);
                            } else if (code.equalsIgnoreCase("36001")) {
                                Log.e("TEST", "---- sendReport() ERROR - invalid userId");
                                mToastMessage = "Unable to send report, user ID not valid.";
                                mHandler.sendEmptyMessage(MSG_TOAST);
                            } else {
                                Log.e("TEST", "---- sendReport() server error code: " + code);
                                mToastMessage = "Unable to send report, please try again later..";
                                mHandler.sendEmptyMessage(MSG_TOAST);
                            }
                        } catch (Exception e) {
                            Log.e("TEST", "---- sendReport() error: " + e.getMessage());
                        }
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR on sendReport()");
                e.printStackTrace();
            }
        }
    }

    public void sendMessage(long uid, long bid, final String message) {
        // GeekUtility.showProgressDialog(this, "Sending message...");
        Log.d("TEST", "---- sendMessage()... connected: " + mSocket.connected());
        if (!mSocket.connected()) {
            // mHandler.sendEmptyMessage(MSG_SHOW_WARNING);
            mErrorTitle = "Connection Error";
            mErrorMessage = "Unable to connect to the server. Please check your connection.";
            mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
        } else {
            try {
                JSONObject data = new JSONObject();
                data.put("userId", uid);
                data.put("bookingId", bid > 0 ? bid : null);
                data.put("message", message);
                mSocket.emit("booking.message.out", data, new Ack() {
                    @Override
                    public void call(Object... args) {
                        try {
                            JSONObject obj = (JSONObject) args[0];
                            Log.d("TEST", "---- sendMessage().ack: " + obj.toString());
                            String code = obj.getString("statusCode");
                            if (code.equalsIgnoreCase("34000")) {
                                // Success, update msgs
                                Log.d("TEST", "---- sendMessage() SUCCESS");
                                mBookingMessages.add(new BookingMessage(mCurrBooking, message, true));
                                mHandler.sendEmptyMessage(MSG_ADD_NEW_MSG);
                            } else {
                                Log.e("TEST", "---- sendMessage() server error code: " + code);
                            }
                        } catch (Exception e) {
                            Log.e("TEST", "---- sendMessage() error: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                });
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR on sendMessage()");
                e.printStackTrace();
            }
        }
    }

    // ========== SOCKET LISTENERS ==========

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d("TEST", "---- is socket connected: " + mSocket.connected());
            connectionUpdate(mPref.getUserId());
            if (mSocket.connected()) {
                // check booking.inquire
                bookingInquire(mPref.getUserId(), 0);
            }
        }
    };

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d("TEST", "---- socket disconnect");
            try {
                JSONObject json = new JSONObject();
                json.put("message", "ACK");
                if (args[args.length - 1] instanceof Ack) {
                    Ack ack = (Ack) args[args.length - 1];
                    ack.call(json);
                } else {
                    for (int i = 0; i < args.length; i++) {
                        Log.d("TEST", "---- args[" + i + "]: " + args[i]);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener onError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            EngineIOException exception = (EngineIOException) args[0];
            Log.d("TEST", "----- socket error: " + exception.toString());
            exception.printStackTrace();
        }
    };

    private Emitter.Listener onBookingInvite = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            if (mCurrFragment instanceof MapFragment) {
                // do nothing...
            } else {
                mHandler.sendEmptyMessage(MSG_GO_HOME);
            }

            final JSONObject obj = (JSONObject) args[0];
            Log.d("TEST", "---- booking.invite: " + obj.toString());
            try {
                JSONObject json = new JSONObject();
                json.put("message", "ACK");
                Ack ack = (Ack) args[args.length - 1];
                ack.call(json);
            } catch (Exception e) {
                Log.w("TEST", "---- booking.invite: PARSE ERROR");
                e.printStackTrace();
            }

            // Invoke notification
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(MainActivity.this);
            notificationManager.notify((int) System.currentTimeMillis(), mNotifBuilder.build());

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Booking mCurrBooking = new Booking();
                    try {
                        mCurrBooking.setId(obj.getInt("bookingId"));
                        JSONObject pickup = obj.getJSONObject("pickup");
                        mCurrBooking.setPickup(new Coordinate(pickup.getDouble("lat"), pickup.getDouble("lng")));
                        mCurrBooking.setPickupName(obj.getString("pickupName"));
                        JSONObject dropoff = obj.getJSONObject("dropoff");
                        mCurrBooking.setDropoff(new Coordinate(dropoff.getDouble("lat"), dropoff.getDouble("lng")));
                        mCurrBooking.setDropoffName(obj.getString("dropoffName"));
                        mCurrBooking.setDistance(obj.getInt("distance"));
                        mCurrBooking.setDuration(obj.getInt("duration"));
                        JSONObject price = obj.getJSONObject("price");
                        mCurrBooking.setPrice(new Price(
                                price.getDouble("standard"),
                                price.getDouble("succeeding"),
                                price.getDouble("premium"),
                                price.getDouble("total"),
                                price.getDouble("promo")
                        ));
                        mCurrBooking.setMsg(obj.getString("msg"));
                        mCurrBooking.setTimeout(HypeTrikeConstants.TIMEOUT);
                        // ((MapFragment) mCurrFragment).setBooking(mCurrBooking);

                        try {
                            mCurrBooking.setRiderFullName(obj.getString("riderFullname"));
                        } catch (Exception e) {
                            Log.w("TEST", "---- booking.invite: riderFullname PARSE ERROR");
                            e.printStackTrace();
                            mCurrBooking.setRiderFullName("Juan Dela Cruz");
                        }

                        mBookingInvites.add(mCurrBooking);
                        mBookingInvitesAdapter.setList(mBookingInvites);
                        mBookingTitle.setText("REQUESTS (" + mBookingInvitesAdapter.getItemCount() + ")");

                    } catch (Exception e) {
                        // mCurrBooking = null;
                        e.printStackTrace();
                    }

                    if (mBookingInviteDialog == null) {
                        setupBookingInviteDialog();
                        if (mBookingInviteDialog != null && !mBookingInviteDialog.isShowing())
                            mBookingInviteDialog.show();
                    } else {
                        mHandler.sendEmptyMessage(MSG_UPDATE_BOOKING_LIST);
                    }
                }
            });

        }
    };

    private Emitter.Listener onNotifyDriver = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            if (mCurrFragment instanceof MapFragment) {
                // do nothing...
            } else {
                mHandler.sendEmptyMessage(MSG_GO_HOME);
            }
            JSONObject obj = (JSONObject) args[0];
            Log.d("TEST", "---- booking.notify.driver: " + obj.toString());
            try {
                String code = obj.getString("statusCode");
                if (code.equalsIgnoreCase(Status.FAIL_BOOKING_ACCEPTED_BY_OTHER_DRIVER2)) {
//                    mHandler.sendEmptyMessage(MSG_HIDE_BOOKING_DIALOG);
//                    mErrorTitle = "Booking lost";
//                    mErrorMessage = "Oh no! Trip booked with another driver.";
//                    mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
                    //remove booking from list
                    long bid = obj.getLong("bookingId");
                    removeBooking(bid);
                } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_CANCELLED_BY_RIDER2)) {
                    ((MapFragment) mCurrFragment).resetNav();
                    long bid = obj.getLong("bookingId");
                    String reason = obj.getString("reason");
                    if (mCurrBooking != null && mCurrBooking.getId() == bid) {
                        mErrorTitle = "Booking lost";
                        mErrorMessage = "Sorry, the booking had been cancelled by the rider.";
                        if (reason != null && !reason.isEmpty())
                            mErrorMessage = mErrorMessage + "\nReason:\n\t\t" + reason;
                        mHandler.sendEmptyMessage(MSG_ERROR_DIALOG);
                    }
                    //remove booking from list
                    removeBooking(bid);
                } else if (code.equalsIgnoreCase(Status.FAIL_BOOKING_TIMEOUT)) {
                    // no one accepted the booking, remove booking from list
                    long bid = obj.getLong("bookingId");
                    removeBooking(bid);
                }
                JSONObject json = new JSONObject();
                json.put("message", "ACK");
                Ack ack = (Ack) args[args.length - 1];
                ack.call(json);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    };

    private Emitter.Listener onMessageReceived = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            final JSONObject obj = (JSONObject) args[0];
            Log.d("TEST", "---- booking.message.in: " + obj.toString());
            try {

                JSONObject json = new JSONObject();
                json.put("message", "ACK");
                Ack ack = (Ack) args[args.length - 1];
                ack.call(json);

                String message = obj.getString("message");
                mBookingMessages.add(new BookingMessage(mCurrBooking, message, false));
                mHandler.sendEmptyMessage(MSG_ADD_NEW_MSG);

            } catch (Exception e) {
                Log.e("TEST", "---- ERROR on booking.message.in: " + e.getMessage());
                e.printStackTrace();
            }

        }
    };

    private Emitter.Listener onNotificationReceived = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            final JSONObject obj = (JSONObject) args[0];
            Log.d("TEST", "---- user.notification.in: " + obj.toString());
            try {
                JSONObject json = new JSONObject();
                json.put("message", "ACK");
                Ack ack = (Ack) args[args.length - 1];
                ack.call(json);
                JSONArray jMsgs = obj.getJSONArray("notification");
                mNotifs = new ArrayList<>();
                for (int i = 0; i < jMsgs.length(); i++) {
                    JSONObject jMsg = jMsgs.getJSONObject(i);
                    String sender = jMsg.getString("senderName");
                    String message = jMsg.getString("message");
                    String dateTime = jMsg.getString("dateTime");
                    String date = GeekUtility.changeDateFormat(dateTime,
                            "yyyy-MM-dd HH:mm:ss",
                            "MMM dd, yyy - hh:mm aa");
                    mNotifs.add(new NotificationMsg(sender, message, date));
                }
                mHandler.sendEmptyMessage(MSG_SHOW_NOTIF);
            } catch (Exception e) {
                Log.e("TEST", "---- ERROR on booking.message.in: " + e.getMessage());
                e.printStackTrace();
            }

        }
    };

    private void removeBooking(long bid) {
        Iterator itr = mBookingInvites.iterator();
        while (itr.hasNext()) {
            long id = ((Booking) itr.next()).getId();
            if (bid == id) {
                itr.remove();
                break;
            }
        }
        mHandler.sendEmptyMessage(MSG_UPDATE_BOOKING_LIST_ON_BG);
    }

    private void setupNotification() {

        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        mNotifBuilder = new NotificationCompat.Builder(this, HypeTrikeConstants.CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("HypeTrike Booking")
                .setContentText("A booking has been received! Please login to HypeTrike.")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "HypeTrike Driver";
            String description = "HypeTrike Driver channel ID";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(HypeTrikeConstants.CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Invoke notification - transferred to booking invite emitter
        // NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        // notificationManager.notify((int) System.currentTimeMillis(), mNotifBuilder.build());
    }

    private void resetLocService() {
        mCurrBooking = null;
        mPref.setCurrBID(0);
    }

}
