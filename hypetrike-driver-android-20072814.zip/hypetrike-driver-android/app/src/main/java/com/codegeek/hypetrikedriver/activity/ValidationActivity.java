package com.codegeek.hypetrikedriver.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.TextView;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.api.UserAPI;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.util.GeekFont;
import com.codegeek.hypetrikedriver.util.GeekUtility;

public class ValidationActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int MSG_START_MAIN = 1;
    private static final int MSG_SHOW_TOAST = 2;

    private HypeTrikePreferences mPref;
    private String mToastMsg = "Unknown server error.";


    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_START_MAIN:
                    GeekUtility.hideProgressDialog(ValidationActivity.this);
                    startMainActivity();
                    break;
                case MSG_SHOW_TOAST:
                    GeekUtility.hideProgressDialog(ValidationActivity.this);
                    GeekUtility.showToast(ValidationActivity.this, mToastMsg);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validation);
        setupData();
        setupViews();
    }

    private void setupData() {
        GeekUtility.initToast(this);
        mPref = new HypeTrikePreferences(this);
    }

    private void setupViews() {
        TextView header = findViewById(R.id.tv_header);
        header.setTypeface(GeekFont.getHeaderTypeFace(this));

        findViewById(R.id.btn_next).setOnClickListener(this);

        final PinEntryEditText pinEntry = findViewById(R.id.et_pin_entry);
        pinEntry.requestFocus();
        pinEntry.setOnPinEnteredListener(new PinEntryEditText.OnPinEnteredListener() {
            @Override
            public void onPinEntered(final CharSequence str) {
                new Thread() {
                    public void run() {
                        boolean success = UserAPI.validate(mPref.getUserId(), str.toString());
                        mPref.setValidated(success);
                        if (success) {
                            boolean loggedIn = UserAPI.login(mPref);
                            if (loggedIn) {
                                mHandler.sendEmptyMessage(MSG_START_MAIN);
                            } else {
                                pinEntry.setText(null);
                                mToastMsg = UserAPI.errorMessage;
                                mHandler.sendEmptyMessage(MSG_SHOW_TOAST);
                            }
                        } else {
                            pinEntry.setText(null);
                            mToastMsg = UserAPI.errorMessage;
                            mHandler.sendEmptyMessage(MSG_SHOW_TOAST);
                        }
                    }
                }.start();
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_next:
                startMainActivity();
                break;
        }
    }

    private void startMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        startActivity(intent);
    }
}