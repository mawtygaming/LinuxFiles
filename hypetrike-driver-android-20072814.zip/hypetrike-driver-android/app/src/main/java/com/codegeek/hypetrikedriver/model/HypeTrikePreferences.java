package com.codegeek.hypetrikedriver.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;

import java.util.ArrayList;

/**
 * Created by jeacabal on 13/02/2018.
 */

public class HypeTrikePreferences {


    public static final String VPN_PREFERENCES = "hypetrikedriver_preferences";
    private static String SMS_GATEWAYS = "hypetrikedriver_pref_sms_gateways";
    private static String ADS_LINKS = "hypetrikedriver_pref_ads_links";
    private static String ADS_REF_INTERVAL = "hypetrikedriver_pref_ads_refresh_interval";
    private static String VALIDATED = "hypetrikedriver_pref_validated";
    private static String USER_ID = "hypetrikedriver_pref_uid";
    private static String USER_FIRST_NAME = "hypetrikedriver_pref_fname";
    private static String USER_LAST_NAME = "hypetrikedriver_pref_lname";
    private static String USER_EMAIL = "hypetrikedriver_pref_email";
    private static String USER_MOBILE = "hypetrikedriver_pref_mobile";
    private static String CURR_BID = "hypetrikedriver_pref_current_bid";
    private static SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    public HypeTrikePreferences(Context ctx) {
        preferences = ctx.getSharedPreferences(VPN_PREFERENCES, Context.MODE_PRIVATE);
        editor = preferences.edit();
    }

    public void clear() {
        editor.clear();
        editor.commit();
    }

    public void setSMSGateways(JSONArray arr) {
        editor.putString(SMS_GATEWAYS, arr.toString());
        editor.commit();
    }

    public ArrayList<String> getSMSGateways() {
        ArrayList list = new ArrayList();
        String str = preferences.getString(SMS_GATEWAYS, null);
        if (str != null) {
            try {
                JSONArray arr = new JSONArray(str);
                for (int i = 0; i < arr.length(); i++) {
                    list.add(arr.get(i).toString());
                }
            } catch (Exception e) {
                Log.e("TEST", "pref getSMSGateways() error: " + e.getMessage());
            }

        }

        return list;
    }

    public void setAdsLinks(JSONArray arr) {
        editor.putString(ADS_LINKS, arr.toString());
        editor.commit();
    }

    public ArrayList<String> getAdsLinks() {
        ArrayList list = new ArrayList();
        String str = preferences.getString(ADS_LINKS, null);
        if (str != null) {
            try {
                JSONArray arr = new JSONArray(str);
                for (int i = 0; i < arr.length(); i++) {
                    list.add(arr.get(i).toString());
                }
            } catch (Exception e) {
                Log.e("TEST", "pref getAdsLinks() error: " + e.getMessage());
            }

        }

        return list;
    }

    public void setAdsRefInterval(int interval) {
        editor.putInt(ADS_REF_INTERVAL, interval);
        editor.commit();
    }

    public int getAdsRefInterval() {
        return preferences.getInt(ADS_REF_INTERVAL, 5000);
    }

    public void setValidated(boolean value) {
        editor.putBoolean(VALIDATED, value);
        editor.commit();
    }

    public boolean isValidated() {
        return preferences.getBoolean(VALIDATED, false);
    }

    public void setUserId(long uid) {
        editor.putLong(USER_ID, uid);
        editor.commit();
    }

    public long getUserId() {
        long value = Long.parseLong("-1");
        try {
            return preferences.getLong(USER_ID, value);
        } catch (ClassCastException e) {
            return value;
        }
    }

    public void setFirstName(String str) {
        editor.putString(USER_FIRST_NAME, str);
        editor.commit();
    }

    public String getFirstName() {
        return preferences.getString(USER_FIRST_NAME, null);
    }

    public void setLastName(String str) {
        editor.putString(USER_LAST_NAME, str);
        editor.commit();
    }

    public String getLastName() {
        return preferences.getString(USER_LAST_NAME, null);
    }

    public void setEmail(String str) {
        editor.putString(USER_EMAIL, str);
        editor.commit();
    }

    public String getEmail() {
        return preferences.getString(USER_EMAIL, null);
    }

    public void setMobile(String str) {
        editor.putString(USER_MOBILE, str);
        editor.commit();
    }

    public String getMobile() {
        return preferences.getString(USER_MOBILE, null);
    }


    public void setCurrBID(long bid) {
        editor.putLong(CURR_BID, bid);
        editor.commit();
    }

    public long getCurrBID() {
        return preferences.getLong(CURR_BID, 0);
    }

}
