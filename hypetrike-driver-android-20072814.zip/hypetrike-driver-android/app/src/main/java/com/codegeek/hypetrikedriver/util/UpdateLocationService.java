package com.codegeek.hypetrikedriver.util;

import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Looper;
import android.util.Log;

import com.codegeek.hypetrikedriver.model.Booking;
import com.codegeek.hypetrikedriver.model.Coordinate;
import com.codegeek.hypetrikedriver.model.HypeTrikeConstants;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.json.JSONObject;

import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;

public class UpdateLocationService extends IntentService {

    public static final String ACTION_UPDATE_LOCATION = "update.location";
    private static final String TAG = "TEST - UpdateLocService";

    private FusedLocationProviderClient mFusedLocationProviderClient;
    private LocationRequest mLocationRequest;
    private LocationCallback mLocationCallback;
    private Socket mSocket;
    private HypeTrikePreferences mPref;
    private int mDelay = 5000;
    private static boolean mRunLocThread = false;

    public UpdateLocationService() {
        super("UpdateLocationService");
    }

    public static void startUpdateLocation(Context context, Booking booking) {
        Log.d(TAG, "---- UpdateLocationService.startUpdateLocation()");
        Intent intent = new Intent(context, UpdateLocationService.class);
        intent.setAction(ACTION_UPDATE_LOCATION);
        intent.putExtra("booking", booking);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "---- UpdateLocationService.onHandleIntent()");
        if (intent != null && intent.getAction() != null) {
            final String action = intent.getAction();
            if (action.equals(ACTION_UPDATE_LOCATION)) {
                try {
                    // setup data
                    mPref = new HypeTrikePreferences(getApplicationContext());
                    mRunLocThread = true;

                    IO.Options opts = new IO.Options();
                    opts.forceNew = true;
                    mSocket = IO.socket(HypeTrikeConstants.SOCKET_URL, opts);
                    mSocket.connect();

                    mLocationRequest = new LocationRequest();
                    mLocationRequest.setInterval(mDelay);
                    mLocationRequest.setFastestInterval(5000);
                    mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
                    mLocationRequest.setMaxWaitTime(mDelay);

                    Booking booking = (Booking) intent.getSerializableExtra("booking");
                    final long bid = booking == null ? 0 : booking.getId();
                    mLocationCallback = new LocationCallback() {
                        @Override
                        public void onLocationResult(LocationResult locationResult) {
                            for (Location location : locationResult.getLocations()) {
                                // update location to server
                                Log.d(TAG, "---- currBid | bid: " + mPref.getCurrBID() + " | " + bid);
                                if (mPref.getCurrBID() == bid) {
                                    updateLocation(mPref.getUserId(), bid,
                                            location.getLatitude(), location.getLongitude());
                                    // broadcast location to MainActivity
                                    sendLocation(new Coordinate(location.getLatitude(), location.getLongitude()), Activity.RESULT_OK);
                                }
                            }
                        }
                    };

                    mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getApplicationContext());
                    updateLocation(bid);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(TAG, e.getMessage());
                }
            }
        }
    }

    private void updateLocation(final long bid) {
        new Thread() {
            public void run() {
                try {
                    while (mRunLocThread && bid == mPref.getCurrBID()) {
                        mFusedLocationProviderClient.requestLocationUpdates(mLocationRequest,
                                mLocationCallback, Looper.getMainLooper());
                        Thread.sleep(mDelay);
                    }
                } catch (SecurityException se) {
                    mRunLocThread = false;
                    se.printStackTrace();
                    Log.e(TAG, se.getMessage());
                } catch (Exception e) {
                    mRunLocThread = false;
                    e.printStackTrace();
                    Log.e(TAG, e.getMessage());
                }
            }
        }.start();

    }

    private void updateLocation(long uid, long bid, double lat, double lng) {
        try {
            JSONObject data = new JSONObject();
            data.put("userId", uid);
            data.put("bookingId", bid > 0 ? bid : "null");
            JSONObject location = new JSONObject();
            location.put("lat", lat);
            location.put("lng", lng);
            data.put("location", location);

            // Log.d(TAG, "---- location.update | data: " + data.toString());

            mSocket.emit("location.update", data, new Ack() {
                @Override
                public void call(Object... args) {
                    JSONObject obj = (JSONObject) args[0];
                    Log.d(TAG, "---- locationUpdate().ack: " + obj.toString());
                }
            });
        } catch (Exception e) {
            Log.e("TEST", "---- ERROR on locationUpdate()");
            e.printStackTrace();
        }
    }

    private void sendLocation(Coordinate coor, int result) {
        Intent intent = new Intent(ACTION_UPDATE_LOCATION);
        intent.putExtra("coordinates", coor);
        intent.putExtra("result", result);
        sendBroadcast(intent);
    }
}
