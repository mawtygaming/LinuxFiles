package com.codegeek.hypetrikedriver.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.adapter.BalTransactionsAdapter;
import com.codegeek.hypetrikedriver.api.DataAPI;
import com.codegeek.hypetrikedriver.model.Balance;
import com.codegeek.hypetrikedriver.model.BalanceTransaction;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class BalancesFragment extends Fragment implements View.OnClickListener {

    private HypeTrikePreferences mPref;
    private String mToastMessage = "";

    private Double mCurrentBalanceAmt;
    private ArrayList<BalanceTransaction> mTransactions;
    private ArrayList<BalanceTransaction> mFilteredTransactions;
    private int queryOffset = 0;
    private int pageSize = 10;
    private String mCurrentParam;
    private boolean isFiltered = false;

    private TextView mCurrentBalance;
    private SwipeRefreshLayout mParentSRL;
    private RecyclerView mRvTransactions;
    private BalTransactionsAdapter mTransactionsAdapter;
    private TextView mTitle;
    private TextView mNoItemsLabel;

    private static final int MSG_UPDATE_BALANCE = 0;
    private static final int MSG_TOAST = 1;

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_UPDATE_BALANCE:
                    GeekUtility.hideProgressDialog(getContext());
                    mCurrentBalance.setText(String.format("P%.2f", mCurrentBalanceAmt));
                    if (mTransactions == null || mTransactions.isEmpty()) {
                        mTransactionsAdapter.setList(new ArrayList<BalanceTransaction>());
                        mRvTransactions.setVisibility(View.GONE);
                        mNoItemsLabel.setVisibility(View.VISIBLE);
                    } else {
                        mTransactionsAdapter.setList(mTransactions);
                        mRvTransactions.setVisibility(View.VISIBLE);
                        mNoItemsLabel.setVisibility(View.GONE);
                    }
                    mParentSRL.setRefreshing(false);
                    break;
                case MSG_TOAST:
                    GeekUtility.hideProgressDialog(getContext());
                    GeekUtility.showToast(getContext(), mToastMessage);
                    mParentSRL.setRefreshing(false);
                    break;
            }
        }
    };

    public static BalancesFragment newInstance() {
        return new BalancesFragment();
    }

    public BalancesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_balance, container, false);
        setupData();
        setupViews(rootView);
        fetchData(queryOffset, pageSize, mCurrentParam);
        return rootView;
    }

    private void setupData() {
        mPref = new HypeTrikePreferences(getContext());
        mTransactions = new ArrayList<>();
        mFilteredTransactions = new ArrayList<>();
        mTransactionsAdapter = new BalTransactionsAdapter(getContext(),
                new ArrayList<BalanceTransaction>());
    }

    private void setupViews(View rootView) {

        mCurrentBalance = rootView.findViewById(R.id.tv_balance);
        mTitle = rootView.findViewById(R.id.tv_title);

        mParentSRL = rootView.findViewById(R.id.parent_srl);
        // Setup refresh listener which triggers new data loading
        mParentSRL.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (!isFiltered) {
                    // Your code to refresh the list here.
                    // Make sure you call mParentSRL.setRefreshing(false)
                    // once the network request has completed successfully.
                    mTransactions = new ArrayList<>();
                    queryOffset = 0;
                    pageSize = 10;
                    fetchData(queryOffset, pageSize, mCurrentParam);
                } else {
                    mToastMessage = "Switch to ALL tab to refresh.";
                    mHandler.sendEmptyMessage(MSG_TOAST);
                }
            }
        });


        mNoItemsLabel = rootView.findViewById(R.id.tv_no_items);

        mRvTransactions = rootView.findViewById(R.id.rv_transaction_list);
        mRvTransactions.setAdapter(mTransactionsAdapter);

        final LinearLayoutManager lm = new LinearLayoutManager(getContext());
        mRvTransactions.setLayoutManager(lm);
        mRvTransactions.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int visibleItemCount = lm.getChildCount();
                int totalItemCount = lm.getItemCount();
                int firstVisibleItemPosition = lm.findFirstVisibleItemPosition();

                if (isFiltered) {
                    mParentSRL.setRefreshing(false);
                } else {
                    // Load more if we have reach the end to the recyclerView
                    if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount && firstVisibleItemPosition >= 0) {
                        loadMoreItems();
                    }
                }

            }
        });

        mRvTransactions.setVisibility(View.GONE);
        mNoItemsLabel.setVisibility(View.VISIBLE);

        rootView.findViewById(R.id.btn_all).setOnClickListener(this);
        rootView.findViewById(R.id.btn_top_up).setOnClickListener(this);
        rootView.findViewById(R.id.btn_incentives).setOnClickListener(this);
        rootView.findViewById(R.id.btn_promos).setOnClickListener(this);
        rootView.findViewById(R.id.btn_service_fee).setOnClickListener(this);

    }


    private void fetchData(final int offset, final int pageSize, final String param) {

        GeekUtility.showProgressDialog(getContext(), "Fetching balance information...");
        new Thread() {
            public void run() {
                try {
                    // Set startDate and endDate to null to get all transactions
                    Balance balance = DataAPI.getBalances(mPref.getUserId(), offset, pageSize,
                            param, null, null);
                    if (balance != null) {
                        mCurrentParam = balance.getParam();
                        if (queryOffset == 0) {
                            // update balance only on first set of inquiry
                            mCurrentBalanceAmt = balance.getCurrentBalance();
                        }
                        mTransactions.addAll(balance.getTransactions());
                        mHandler.sendEmptyMessage(MSG_UPDATE_BALANCE);
                    } else {
                        mToastMessage = DataAPI.errorMessage;
                        mHandler.sendEmptyMessage(MSG_TOAST);
                    }
                } catch (Exception e) {
                    Log.e("TEST", "----- Error on balances.fetchData()");
                    e.printStackTrace();
                    mToastMessage = e.getMessage();
                    mHandler.sendEmptyMessage(MSG_TOAST);
                }
            }
        }.start();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_all:
                filter(0, "All Transactions");
                break;
            case R.id.btn_service_fee:
                filter(1, "Service Fees");
                break;
            case R.id.btn_promos:
                filter(2, "Promos");
                break;
            case R.id.btn_top_up:
                filter(3, "Top Ups");
                break;
            case R.id.btn_incentives:
                filter(4, "Incentives");
                break;
        }
    }

    private void loadMoreItems() {
        if (mTransactions.size() >= 10) {
            // init offset=0 the frist time and increase the offset + the PAGE_SIZE when loading more items
            queryOffset = queryOffset + pageSize;
            // HERE YOU LOAD the next batch of items
            fetchData(queryOffset, pageSize, mCurrentParam);
        }
    }

    private void filter(int type, String title) {
        mTitle.setText(title);
        if (type == 0) {
            isFiltered = false;
            if (mTransactions == null || mTransactions.isEmpty()) {
                mTransactionsAdapter.setList(new ArrayList<BalanceTransaction>());
                mRvTransactions.setVisibility(View.GONE);
                mNoItemsLabel.setVisibility(View.VISIBLE);
            } else {
                mTransactionsAdapter.setList(mTransactions);
                mRvTransactions.setVisibility(View.VISIBLE);
                mNoItemsLabel.setVisibility(View.GONE);
            }
        } else {
            isFiltered = true;
            mFilteredTransactions = new ArrayList<>();
            for (BalanceTransaction t : mTransactions) {
                if (t.getType() == type) {
                    mFilteredTransactions.add(t);
                }
            }
            Log.d("TEST", "--- total filtered items: " + mFilteredTransactions.size());
            if (mFilteredTransactions == null || mFilteredTransactions.isEmpty()) {
                mTransactionsAdapter.setList(new ArrayList<BalanceTransaction>());
                mRvTransactions.setVisibility(View.GONE);
                mNoItemsLabel.setVisibility(View.VISIBLE);
            } else {
                mTransactionsAdapter.setList(mFilteredTransactions);
                mRvTransactions.setVisibility(View.VISIBLE);
                mNoItemsLabel.setVisibility(View.GONE);
            }
        }

    }


}
