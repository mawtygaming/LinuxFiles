package com.codegeek.hypetrikedriver.model;

public class BookingMessage {

    private Booking booking;
    private String message;
    private boolean isMine;

    public BookingMessage(Booking booking, String message, boolean isMine) {
        this.booking = booking;
        this.message = message;
        this.isMine = isMine;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isMine() {
        return isMine;
    }

    public void setMine(boolean mine) {
        isMine = mine;
    }
}
