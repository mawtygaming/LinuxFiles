package com.codegeek.hypetrikedriver.model;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import android.util.AttributeSet;

import com.codegeek.hypetrikedriver.util.GeekFont;


public class HeaderTextView extends AppCompatTextView {
    public HeaderTextView(Context context) {
        super(context);
        this.setTypeface(GeekFont.getHeaderTypeFace(context));
    }

    public HeaderTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.setTypeface(GeekFont.getHeaderTypeFace(context));
    }

    public HeaderTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.setTypeface(GeekFont.getHeaderTypeFace(context));
    }
}
