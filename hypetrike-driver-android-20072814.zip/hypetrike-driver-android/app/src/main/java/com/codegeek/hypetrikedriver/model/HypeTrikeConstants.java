package com.codegeek.hypetrikedriver.model;

public class HypeTrikeConstants {

    public static final String DOMAIN = "139.162.50.254";
    public static final int PORT = 8080;
    public static final String HEADER_AUTH = "Basic aHlwZXRyaWtlOmh5cGV0cmlrZTEyMzQ=";
    public static final String SOCKET_URL = "http://139.162.50.254:1080";
    public static final int TIMEOUT = 90000; // milliseconds
    public static final String CHANNEL_ID = "HYPETRIKE_DRIVER_CHANNEL";
}
