package com.codegeek.hypetrikedriver.util;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;

public class GeekFont {

    private static Typeface header;
    private static Typeface normal;
    private static Typeface bold;

    public static Typeface getHeaderTypeFace(Context ctx) {
        if (header == null) {
            header = Typeface.createFromAsset(ctx.getAssets(), "big_john.otf");
        }
        return header;
    }

    public static Typeface getNormalTypeFace(Context ctx) {
        if (normal == null) {
            normal = Typeface.createFromAsset(ctx.getAssets(), "helvetica_neue_regular.ttf");
        }
        return normal;
    }

    public static Typeface getBoldTypeFace(Context ctx) {
        if (bold == null) {
            bold = Typeface.createFromAsset(ctx.getAssets(), "helvetica_neue_bold.ttf");
        }
        return bold;
    }

    public static SpannableString applyFont(String text, Typeface typeface) {
        SpannableString newString = new SpannableString(text);
        newString.setSpan(new GeekTypeFaceSpan("", typeface), 0,
                newString.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        return newString;
    }
}
