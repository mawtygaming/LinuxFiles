package com.codegeek.hypetrikedriver.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.BookingMessage;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<BookingMessage> messages;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout parent;
        public TextView message;

        public MyViewHolder(View view) {
            super(view);
            parent = view.findViewById(R.id.parent_msg_item);
            message = view.findViewById(R.id.tv_message);
        }
    }

    public MessagesAdapter(Context context, ArrayList<BookingMessage> messages) {
        this.context = context;
        this.messages = messages;
    }

    public void setList(ArrayList<BookingMessage> messages) {
        this.messages = messages;
        this.notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.list_item_msg, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        BookingMessage msg = messages.get(position);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        if (msg.isMine()) {
            params.setMargins(GeekUtility.getPXfromDP(context, 40), // left
                    GeekUtility.getPXfromDP(context, 10), // top
                    GeekUtility.getPXfromDP(context, 10), // right
                    0); // bottom
            params.gravity = Gravity.RIGHT;
            holder.parent.setBackground(context.getResources().getDrawable(R.drawable.bg_msg_right));
        } else {
            params.setMargins(GeekUtility.getPXfromDP(context, 10), // left
                    GeekUtility.getPXfromDP(context, 10), // top
                    GeekUtility.getPXfromDP(context, 40), // right
                    0); // bottom
            params.gravity = Gravity.LEFT;
            holder.parent.setBackground(context.getResources().getDrawable(R.drawable.bg_msg_left));
        }
        holder.parent.setLayoutParams(params);
        holder.message.setText(msg.getMessage());
        Log.d("TEST", "--- bid|msg: [" + msg.getBooking().getId() + "] " + msg.getMessage());
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }
}
