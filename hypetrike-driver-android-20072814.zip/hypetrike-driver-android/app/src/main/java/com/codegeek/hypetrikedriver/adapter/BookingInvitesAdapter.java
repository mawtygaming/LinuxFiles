package com.codegeek.hypetrikedriver.adapter;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.CountDownTimer;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.activity.MainActivity;
import com.codegeek.hypetrikedriver.model.Booking;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class BookingInvitesAdapter extends RecyclerView.Adapter<BookingInvitesAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<Booking> items;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView pickup, dropoff, instructions, bookingId, fare;
        public Button accept;

        public MyViewHolder(View view) {
            super(view);
            pickup = view.findViewById(R.id.tv_pickup_address);
            dropoff = view.findViewById(R.id.tv_destination_address);
            instructions = view.findViewById(R.id.tv_instructions_msg);
            bookingId = view.findViewById(R.id.tv_booking_id);
            fare = view.findViewById(R.id.tv_booking_price);
            accept = view.findViewById(R.id.btn_accept);
        }
    }

    public BookingInvitesAdapter(Context context, ArrayList<Booking> items) {
        this.context = context;
        this.items = items;
    }

    public void setList(ArrayList<Booking> items) {
        this.items = items;
        this.notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.list_item_booking_invite, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final Booking booking = items.get(position);

        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            Address address1 = geocoder.getFromLocation(booking.getPickup().getLat(),
                    booking.getPickup().getLng(), 1).get(0);
            String pickupAddress = address1.getAddressLine(0);
            holder.pickup.setText(pickupAddress);
        } catch (Exception e) {
            e.printStackTrace();
            holder.pickup.setText(booking.getPickupName());
        }
        try {
            Address address2 = geocoder.getFromLocation(booking.getDropoff().getLat(),
                    booking.getDropoff().getLng(), 1).get(0);
            String dropoffAddress = address2.getAddressLine(0);
            holder.dropoff.setText(dropoffAddress);
        } catch (Exception e) {
            e.printStackTrace();
            holder.dropoff.setText(booking.getDropoffName());
        }

        holder.instructions.setText(booking.getMsg());
        holder.bookingId.setText("Booking ID: " + booking.getId());
        holder.fare.setText(String.format("Fare: P%.2f", booking.getPrice().getTotal()));

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) context).bookingAccept(booking);
            }
        });

        startTimer(booking, holder.accept);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void startTimer(final Booking booking, final Button accept) {
        new CountDownTimer(booking.getTimeout(), 1000) {
            public void onTick(long millisUntilDone) {
                booking.setTimeout(millisUntilDone);
                accept.setText("Accept (" + (millisUntilDone / 1000) + ")");
            }

            public void onFinish() {
                // remove booking id it still exist.
                Iterator itr = items.iterator();
                while (itr.hasNext()) {
                    long id = ((Booking) itr.next()).getId();
                    if (booking.getId() == id) {
                        itr.remove();
                        break;
                    }
                }
                BookingInvitesAdapter.this.notifyDataSetChanged();
            }
        }.start();
    }
}
