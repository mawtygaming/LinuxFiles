package com.codegeek.hypetrikedriver.model;

import org.json.JSONObject;

import java.io.Serializable;

public class Price implements Serializable {

    private double standard;
    private double succeeding;
    private double premium;
    private double total;
    private double promo;

    public Price(double standard, double succeeding, double premium, double total, double promo) {
        this.standard = standard;
        this.succeeding = succeeding;
        this.premium = premium;
        this.total = total;
        this.promo = promo;
    }

    public double getStandard() {
        return standard;
    }

    public void setStandard(double standard) {
        this.standard = standard;
    }

    public double getSucceeding() {
        return succeeding;
    }

    public void setSucceeding(double succeeding) {
        this.succeeding = succeeding;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getPromo() {
        return promo;
    }

    public void setPromo(double promo) {
        this.promo = promo;
    }

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        try {
            json.put("standard", standard);
            json.put("succeeding", succeeding);
            json.put("premium", premium);
            json.put("total", total);
            json.put("promo", promo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }
}
