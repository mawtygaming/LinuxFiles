package com.codegeek.hypetrikedriver.model;

import java.util.ArrayList;

public class DriverTransaction {


    private String param;
    private ArrayList<Transaction> transactions;

    public DriverTransaction(String param, ArrayList<Transaction> transactions) {
        this.param = param;
        this.transactions = transactions;
    }


    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(ArrayList<Transaction> transactions) {
        this.transactions = transactions;
    }

    public static class Transaction {
        private String date;
        private long bookingId;
        private double totalPrice;
        private Coordinate pickup;
        private Coordinate dropoff;
        private String pickupName;
        private String dropoffName;

        public Transaction(String date, long bookingId, double totalPrice,
                                 Coordinate pickup, Coordinate dropoff, String pickupName, String dropoffName) {
            this.date = date;
            this.bookingId = bookingId;
            this.totalPrice = totalPrice;
            this.pickup = pickup;
            this.dropoff = dropoff;
            this.pickupName = pickupName;
            this.dropoffName = dropoffName;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public long getBookingId() {
            return bookingId;
        }

        public void setBookingId(long bookingId) {
            this.bookingId = bookingId;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(double totalPrice) {
            this.totalPrice = totalPrice;
        }

        public Coordinate getPickup() {
            return pickup;
        }

        public void setPickup(Coordinate pickup) {
            this.pickup = pickup;
        }

        public Coordinate getDropoff() {
            return dropoff;
        }

        public void setDropoff(Coordinate dropoff) {
            this.dropoff = dropoff;
        }

        public String getPickupName() {
            return pickupName;
        }

        public void setPickupName(String pickupName) {
            this.pickupName = pickupName;
        }

        public String getDropoffName() {
            return dropoffName;
        }

        public void setDropoffName(String dropoffName) {
            this.dropoffName = dropoffName;
        }
    }
}
