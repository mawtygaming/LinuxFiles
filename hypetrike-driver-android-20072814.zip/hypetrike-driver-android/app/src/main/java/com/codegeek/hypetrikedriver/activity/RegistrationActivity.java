package com.codegeek.hypetrikedriver.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.util.GeekFont;
import com.codegeek.hypetrikedriver.util.GeekUtility;

public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int MSG_START_VALIDATION = 0;
    private static final int MSG_SHOW_ERROR = 1;

    private HypeTrikePreferences mPref;
    private EditText mEtFName;
    private EditText mEtLName;
    private EditText mEtEmail;
    private EditText mEtMobile;


    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_START_VALIDATION:
                    GeekUtility.hideProgressDialog(RegistrationActivity.this);
                    startValidationActivity();
                    break;
                case MSG_SHOW_ERROR:
                    GeekUtility.hideProgressDialog(RegistrationActivity.this);
                    GeekUtility.showToast(RegistrationActivity.this, "Please fill up all the fields.");
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setupData();
        setupViews();
    }

    private void setupData() {
        GeekUtility.initToast(this);
        mPref = new HypeTrikePreferences(this);
    }

    private void setupViews() {
        TextView header = findViewById(R.id.tv_header);
        header.setTypeface(GeekFont.getHeaderTypeFace(this));

        findViewById(R.id.btn_back).setOnClickListener(this);
        findViewById(R.id.btn_submit).setOnClickListener(this);

        mEtFName = findViewById(R.id.et_fname);
        mEtLName = findViewById(R.id.et_lname);
        mEtEmail = findViewById(R.id.et_email);
        mEtMobile = findViewById(R.id.et_mobile);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                RegistrationActivity.this.finish();
                break;
            case R.id.btn_submit:
                submit();
                break;
        }
    }

    private void submit() {
        GeekUtility.showProgressDialog(this, "Loading...");
        new Thread() {
            public void run() {
                try {
                    Thread.sleep(2000);
                    if (!mEtFName.getText().toString().isEmpty() && !mEtLName.getText().toString().isEmpty()
                            && !mEtEmail.getText().toString().isEmpty() && !mEtMobile.getText().toString().isEmpty()) {
                        mPref.setFirstName(mEtFName.getText().toString());
                        mPref.setLastName(mEtLName.getText().toString());
                        mPref.setEmail(mEtEmail.getText().toString());
                        mPref.setMobile(mEtMobile.getText().toString());
                        mHandler.sendEmptyMessage(MSG_START_VALIDATION);
                    } else {
                        mHandler.sendEmptyMessage(MSG_SHOW_ERROR);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }.start();
    }

    private void startValidationActivity() {
        Intent intent = new Intent(getApplicationContext(), ValidationActivity.class);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        startActivity(intent);
    }
}