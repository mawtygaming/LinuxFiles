package com.codegeek.hypetrikedriver.model;

public class NotificationMsg {

    private long id;
    private String senderName;
    private String message;
    private String dateTime;

    public NotificationMsg(long id, String senderName, String message, String dateTime) {
        this.id = id;
        this.senderName = senderName;
        this.message = message;
        this.dateTime = dateTime;
    }

    public NotificationMsg(String senderName, String message, String dateTime) {
        this.senderName = senderName;
        this.message = message;
        this.dateTime = dateTime;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
