package com.codegeek.hypetrikedriver.api;

import android.content.Context;
import android.util.Log;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.Route;
import com.google.android.gms.maps.model.LatLng;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MapsAPI {

    public static String errorMessage = "Unknown error occurred.";

    public static Route getRoute(Context ctx, String pickup, String destination) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("maps.googleapis.com")
                    .addPathSegments("maps/api/directions/json")
                    .query("origin=place_id:" + pickup + "&destination=place_id:"
                            + destination + "&key=" + ctx.getString(R.string.google_maps_key))
                    .build();

            Log.d("TEST", "======= url: " + url);

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            // Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            if (!jResult.getString("status").equalsIgnoreCase("OK")) {
                return null;
            }

            JSONObject jRoute = jResult.getJSONArray("routes").getJSONObject(0);
            JSONObject jLeg = jRoute.getJSONArray("legs").getJSONObject(0);
            int distance = jLeg.getJSONObject("distance").getInt("value");
            int duration = jLeg.getJSONObject("duration").getInt("value");
            String distanceStr = jLeg.getJSONObject("distance").getString("text");
            String durationStr = jLeg.getJSONObject("duration").getString("text");
            String startAddress = jLeg.getString("start_address");
            String endAddress = jLeg.getString("end_address");

            String endLat = jLeg.getJSONObject("end_location").getString("lat");
            String endLng = jLeg.getJSONObject("end_location").getString("lng");
            String startLat = jLeg.getJSONObject("start_location").getString("lat");
            String startLng = jLeg.getJSONObject("start_location").getString("lng");

            LatLng endLatLng = new LatLng(Double.parseDouble(endLat), Double.parseDouble(endLng));
            LatLng startLatLng = new LatLng(Double.parseDouble(startLat), Double.parseDouble(startLng));

            // Paths
            ArrayList<String> paths = new ArrayList<>();
            JSONArray jSteps = jLeg.getJSONArray("steps");
            for (int i = 0; i < jSteps.length(); i++) {
                paths.add(jSteps.getJSONObject(i).getJSONObject("polyline").getString("points"));
            }


            return new Route(distance, duration, distanceStr, durationStr, startAddress, startLatLng, endAddress, endLatLng, paths);
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return null;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return null;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return null;
        }
    }

    public static Route getRoute(Context ctx, LatLng start, LatLng end) {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS) // connect timeout
                    .readTimeout(60, TimeUnit.SECONDS) // socket timeout
                    .build();

            HttpUrl url = new HttpUrl.Builder()
                    .scheme("https")
                    .host("maps.googleapis.com")
                    .addPathSegments("maps/api/directions/json")
                    .query("origin=" + start.latitude + "," + start.longitude + "&destination="
                            + end.latitude + "," + end.longitude + "&key=" + ctx.getString(R.string.google_maps_key))
                    .build();

            Log.d("TEST", "======= url: " + url);

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            Response response = client.newCall(request).execute();
            String result = response.body().string();
            // Log.d("TEST", "======= result: " + result);

            // Parse result
            JSONObject jResult = new JSONObject(result);
            if (jResult.getString("status").equalsIgnoreCase("ZERO_RESULTS")) {
                errorMessage = "No routes found";
                return null;
            } else if (!jResult.getString("status").equalsIgnoreCase("OK")) {
                return null;
            }

            JSONObject jRoute = jResult.getJSONArray("routes").getJSONObject(0);
            JSONObject jLeg = jRoute.getJSONArray("legs").getJSONObject(0);
            int distance = jLeg.getJSONObject("distance").getInt("value");
            int duration = jLeg.getJSONObject("duration").getInt("value");
            String distanceStr = jLeg.getJSONObject("distance").getString("text");
            String durationStr = jLeg.getJSONObject("duration").getString("text");
            String startAddress = jLeg.getString("start_address");
            String endAddress = jLeg.getString("end_address");

            String endLat = jLeg.getJSONObject("end_location").getString("lat");
            String endLng = jLeg.getJSONObject("end_location").getString("lng");
            String startLat = jLeg.getJSONObject("start_location").getString("lat");
            String startLng = jLeg.getJSONObject("start_location").getString("lng");

            LatLng endLatLng = new LatLng(Double.parseDouble(endLat), Double.parseDouble(endLng));
            LatLng startLatLng = new LatLng(Double.parseDouble(startLat), Double.parseDouble(startLng));

            // Paths
            ArrayList<String> paths = new ArrayList<>();
            JSONArray jSteps = jLeg.getJSONArray("steps");
            for (int i = 0; i < jSteps.length(); i++) {
                paths.add(jSteps.getJSONObject(i).getJSONObject("polyline").getString("points"));
            }


            return new Route(distance, duration, distanceStr, durationStr, startAddress, startLatLng, endAddress, endLatLng, paths);
        } catch (ConnectTimeoutException cte) {
            errorMessage = "Connection timeout.";
            cte.printStackTrace();
            return null;
        } catch (SocketException se) {
            errorMessage = "Cannot connect to server";
            se.printStackTrace();
            return null;
        } catch (Exception e) {
            errorMessage = "Unknown error occurred.";
            e.printStackTrace();
            return null;
        }
    }
}
