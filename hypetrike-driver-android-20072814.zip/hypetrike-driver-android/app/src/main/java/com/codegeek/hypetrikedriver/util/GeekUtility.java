package com.codegeek.hypetrikedriver.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import androidx.appcompat.app.AlertDialog;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.codegeek.hypetrikedriver.R;
import com.google.android.gms.maps.model.LatLng;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class GeekUtility {

    private static final int HANDLER_PROGRESS_LOAD_START = 0;
    private static final int HANDLER_PROGRESS_LOAD_FINISH = 1;
    private static final int HANDLER_PROGRESS_UPDATE_MSG = 2;
    private static final int HANDLER_SHOW_TOAST = 3;

    private static Context mContext;
    private static Dialog mProgDialog;
    private static TextView mProgDialogMsg;
    private static boolean mIsCancelable;
    private static String mProgressMessage = "Loading...";
    private static OnDismissListener mOnDismissListener;
    private static Toast mToast;

    // Handler
    @SuppressLint("HandlerLeak")
    private static Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case HANDLER_PROGRESS_LOAD_START:
                    if (mProgDialog == null) {
                        LayoutInflater inflater = ((Activity) (mContext)).getLayoutInflater();
                        View view = inflater.inflate(R.layout.dialog_progress, null);

                        mProgDialog = new Dialog(mContext);
                        mProgDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        mProgDialog.getWindow()
                                .setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                        mProgDialog.setContentView(view);
                        mProgDialogMsg = (TextView) mProgDialog.findViewById(R.id.dialog_message);
                        mProgDialogMsg.setText(mProgressMessage);
                        mProgDialogMsg.setTypeface(GeekFont.getNormalTypeFace(mContext));
                        mProgDialog.setCancelable(mIsCancelable);
                        if (mOnDismissListener != null) {
                            mProgDialog.setOnDismissListener(mOnDismissListener);
                        }
                        try {
                            mProgDialog.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case HANDLER_PROGRESS_LOAD_FINISH:
                    try {
                        mProgDialog.dismiss();
                        mProgDialog = null;
                    } catch (Exception e) {
                    }
                    break;
                case HANDLER_PROGRESS_UPDATE_MSG:
                    mProgDialogMsg.setText(mProgressMessage);
                    break;
                case HANDLER_SHOW_TOAST:
                    mToast.show();
                    break;
            }
        }
    };

    public static void init(Context c) {
        mContext = c;
    }

    public static void initToast(Context c) {
        mToast = Toast.makeText(c, null, Toast.LENGTH_LONG);
    }

    public static void showToast(Context c, String msg) {
        mToast.setText(GeekFont.applyFont(msg, GeekFont.getNormalTypeFace(c)));
        mHandler.sendEmptyMessage(HANDLER_SHOW_TOAST);
    }

    public static int getPXfromDP(Context context, int dp) {
        Resources r = context.getResources();
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics());
        return px;
    }

    public static int getScreenWidth(Context c) {
        return ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getWidth();
    }

    public static int getScreenHeight(Context c) {
        return ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getHeight();
    }

    public static int getScreenOrientation(Context c) {
        return ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
    }

    public static void showProgressDialog(Context c, String msg) {
        showProgressDialog(c, msg, false, null);
    }

    public static void showProgressDialog(Context c, String msg, boolean isCancelable,
                                          OnDismissListener onDismissListener) {
        mProgressMessage = msg;
        mContext = c;
        mIsCancelable = isCancelable;
        mOnDismissListener = onDismissListener;
        mHandler.sendEmptyMessage(HANDLER_PROGRESS_LOAD_START);
    }

    public static void hideProgressDialog(Context c) {
        mContext = c;
        mHandler.sendEmptyMessage(HANDLER_PROGRESS_LOAD_FINISH);
    }

    public static void setProgressDialogMsg(Context c, String msg) {
        mProgressMessage = msg;
        mContext = c;
        mHandler.sendEmptyMessage(HANDLER_PROGRESS_UPDATE_MSG);
    }

    public static String changeDateFormat(String dateStr, String inputPattern, String outputPattern) {
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern, Locale.ENGLISH);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern, Locale.ENGLISH);
        Date date = null;
        String strDate = null;

        try {
            date = inputFormat.parse(dateStr);
            strDate = outputFormat.format(date);
            return strDate;
        } catch (Exception e) {
            Log.d("TEST", "********** ERROR @ GeekGUIUtility.changeDateFormat() **********");
            e.printStackTrace();
            return null;
        }
    }

    public static String getDateString(Date date, String format) {

        SimpleDateFormat inputFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        try {
            return inputFormat.format(date);
        } catch (Exception e) {
            Log.d("TEST", "********** ERROR @ GeekGUIUtility.getDateString() **********");
            e.printStackTrace();
            return null;
        }
    }

    public static Date getDate(String dateStr, String format) {

        SimpleDateFormat inputFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        try {
            return inputFormat.parse(dateStr);
        } catch (Exception e) {
            Log.d("TEST", "********** ERROR @ GeekGUIUtility.getDate() **********");
            e.printStackTrace();
            return null;
        }
    }

    public static String getApplicationVersion(Activity activity) {
        String app_ver = null;
        try {
            app_ver = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionName;
        } catch (NameNotFoundException e) {
            Log.v("error on utility", e.getMessage());
        }
        return app_ver;
    }

    public static String getApplicationBuild(Activity activity) {
        String app_ver = null;
        try {
            int code = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionCode;
            app_ver = String.valueOf(code);
        } catch (NameNotFoundException e) {
            Log.v("error on utility", e.getMessage());
        }
        return app_ver;
    }

    public static String md5(String s) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();


            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static boolean checkConnection(final Activity activity) {
        if (!GeekUtility.isNetworkAvailable(activity)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle("No Internet");
            builder.setMessage("No internet connection detected. Please check your connection then try again.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    activity.finish();
                }
            });
            builder.create().show();
            return false;
        }
        return true;
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static int getAge(int year, int month, int day) {
        Calendar today = Calendar.getInstance();
        Calendar bday = Calendar.getInstance();
        bday.set(year, month - 1, day);

        int age = today.get(Calendar.YEAR) - bday.get(Calendar.YEAR);

        if ((today.get(Calendar.MONTH) < bday.get(Calendar.MONTH))
                || ((today.get(Calendar.MONTH) == bday.get(Calendar.MONTH))
                && (today.get(Calendar.DAY_OF_MONTH) < bday.get(Calendar.DAY_OF_MONTH)))) {
            age--;
        }

        return age;
    }

    public static byte[] serialize(Object obj) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream os = new ObjectOutputStream(out);
            os.writeObject(obj);
            return out.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Object deserialize(byte[] data) {
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(data);
            ObjectInputStream is = new ObjectInputStream(in);
            return is.readObject();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static SecureRandom rnd = new SecureRandom();

    public static String getRandomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++)
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        return sb.toString();
    }

    public static String priceWithDecimal(Double price) {
        DecimalFormat formatter = new DecimalFormat("###,###,###,###.00");
        return formatter.format(price);
    }

    public static String priceWithoutDecimal(Double price) {
        DecimalFormat formatter = new DecimalFormat("###,###,###,###.##");
        return formatter.format(price);
    }

    public static String numberWithComma(long value) {
        DecimalFormat formatter = new DecimalFormat("###,###,###,###");
        return formatter.format(value);
    }

    public static String priceToString(Double price) {
        // String toShow = priceWithoutDecimal(price);
        String toShow = priceWithDecimal(price);
        if (toShow.indexOf(".") > 0) {
            return priceWithDecimal(price);
        } else {
            return priceWithoutDecimal(price);
        }
    }

    /**
     * Method to decode polyline points
     * Courtesy : jeffreysambells.com/2010/05/27/decoding-polylines-from-google-maps-direction-api-with-java
     */
    public static ArrayList<LatLng> decodePoly(String encoded) {

        ArrayList<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }

        return poly;
    }

}
