package com.codegeek.hypetrikedriver.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.model.BalanceTransaction;
import com.codegeek.hypetrikedriver.util.GeekUtility;

import java.util.ArrayList;

public class BalTransactionsAdapter extends RecyclerView.Adapter<BalTransactionsAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<BalanceTransaction> transactions;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView bid, date, pickup, dropoff, total;
        public ImageView icPickup, icDropoff;

        public MyViewHolder(View view) {
            super(view);
            bid = view.findViewById(R.id.tv_bid);
            date = view.findViewById(R.id.tv_date);
            pickup = view.findViewById(R.id.tv_pickup);
            dropoff = view.findViewById(R.id.tv_dropoff);
            total = view.findViewById(R.id.tv_total);
            icPickup = view.findViewById(R.id.ic_pickup);
            icDropoff = view.findViewById(R.id.ic_dropoff);
        }
    }

    public BalTransactionsAdapter(Context context, ArrayList<BalanceTransaction> transactions) {
        this.context = context;
        this.transactions = transactions;
    }

    public void setList(ArrayList<BalanceTransaction> transactions) {
        this.transactions = transactions;
        this.notifyDataSetChanged();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.list_item_transaction, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        BalanceTransaction tx = transactions.get(position);
        try {
            holder.date.setText(GeekUtility.changeDateFormat(tx.getTransactionDate(),
                    "yyyy-MM-dd HH:mm:ss",
                    "MMMM dd, yyyy, hh:mm a"));
        } catch (Exception e) {
            e.printStackTrace();
            holder.date.setText(tx.getTransactionDate());
        }

        int visibility = tx.getType() == 1 ? View.VISIBLE : View.GONE;
        holder.pickup.setVisibility(visibility);
        holder.dropoff.setVisibility(visibility);
        holder.icPickup.setVisibility(visibility);
        holder.icDropoff.setVisibility(visibility);


        switch (tx.getType()){
            case 1: // service fee
                holder.bid.setText("Service Fee BID#: " + tx.getBookingId());
                holder.pickup.setText(tx.getPickupName());
                holder.dropoff.setText(tx.getDropoffName());
                holder.total.setText(String.format("P%.2f", tx.getTotalAmount()));
                break;
            case 2: // promo
                holder.bid.setText("Promo BID#: " + tx.getBookingId());
                holder.total.setText(String.format("P%.2f", tx.getTotalAmount()));
                break;
            case 3: // top up
                holder.bid.setText("Top up");
                holder.total.setText(String.format("P%.2f", tx.getTotalAmount()));
                break;
            case 4: // incentive
                holder.bid.setText("Incentive BID#: " + tx.getBookingId());
                holder.total.setText(String.format("P%.2f", tx.getTotalAmount()));
                break;
        }



    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }
}
