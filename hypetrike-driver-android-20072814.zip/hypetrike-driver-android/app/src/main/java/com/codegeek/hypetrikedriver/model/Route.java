package com.codegeek.hypetrikedriver.model;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class Route {

    private int distance;
    private int duration;
    private String distanceStr;
    private String durationStr;
    private String startAddress;
    private LatLng startLatLng;
    private String endAddress;
    private LatLng endLatLng;
    private ArrayList<String> paths;

    public Route(int distance, int duration, String distanceStr, String durationStr, String startAddress, LatLng startLatLng, String endAddress, LatLng endLatLng, ArrayList paths) {
        this.distance = distance;
        this.duration = duration;
        this.distanceStr = distanceStr;
        this.durationStr = durationStr;
        this.startAddress = startAddress;
        this.startLatLng = startLatLng;
        this.endAddress = endAddress;
        this.endLatLng = endLatLng;
        this.paths = paths;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getDistanceStr() {
        return distanceStr;
    }

    public void setDistanceStr(String distanceStr) {
        this.distanceStr = distanceStr;
    }

    public String getDurationStr() {
        return durationStr;
    }

    public void setDurationStr(String durationStr) {
        this.durationStr = durationStr;
    }

    public String getStartAddress() {
        return startAddress;
    }

    public void setStartAddress(String startAddress) {
        this.startAddress = startAddress;
    }

    public LatLng getStartLatLng() {
        return startLatLng;
    }

    public void setStartLatLng(LatLng startLatLng) {
        this.startLatLng = startLatLng;
    }

    public String getEndAddress() {
        return endAddress;
    }

    public void setEndAddress(String endAddress) {
        this.endAddress = endAddress;
    }

    public LatLng getEndLatLng() {
        return endLatLng;
    }

    public void setEndLatLng(LatLng endLatLng) {
        this.endLatLng = endLatLng;
    }

    public ArrayList<String> getPaths() {
        return paths;
    }

    public void setPaths(ArrayList<String> paths) {
        this.paths = paths;
    }
}
