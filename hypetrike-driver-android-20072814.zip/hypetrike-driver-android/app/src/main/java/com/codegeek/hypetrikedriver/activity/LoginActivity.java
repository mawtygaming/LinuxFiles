package com.codegeek.hypetrikedriver.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.codegeek.hypetrikedriver.R;
import com.codegeek.hypetrikedriver.api.UserAPI;
import com.codegeek.hypetrikedriver.model.HypeTrikePreferences;
import com.codegeek.hypetrikedriver.util.GeekUtility;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int MSG_START_ANIMATION = 0;
    private static final int MSG_START_MAIN = 1;
    private static final int MSG_START_VALIDATION = 2;
    private static final int MSG_SHOW_TOAST = 3;

    private HypeTrikePreferences mPref;
    private LinearLayout mLogo;
    private LinearLayout mParentForm;
    private EditText mEtEmail;
    private EditText mEtMobile;
    private String mMessage;


    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case MSG_START_ANIMATION:
                    slideUp(mLogo);
                    break;
                case MSG_START_MAIN:
                    GeekUtility.hideProgressDialog(LoginActivity.this);
                    startMainActivity();
                    break;
                case MSG_START_VALIDATION:
                    GeekUtility.hideProgressDialog(LoginActivity.this);
                    startValidationActivity();
                    break;
                case MSG_SHOW_TOAST:
                    GeekUtility.hideProgressDialog(LoginActivity.this);
                    GeekUtility.showToast(LoginActivity.this, mMessage);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setupData();
        setupViews();
    }

    private void setupData() {
        GeekUtility.initToast(this);
        mPref = new HypeTrikePreferences(this);
    }

    private void setupViews() {

        mLogo = findViewById(R.id.img_logo);
        mParentForm = findViewById(R.id.parent_form);
        mEtEmail = findViewById(R.id.et_email);
        mEtMobile = findViewById(R.id.et_mobile);

        // Animation
        if (mPref.getUserId() == 0 && mPref.getMobile() == null)
            slideDown(mLogo);
        mParentForm.setVisibility(View.INVISIBLE);
        new Thread() {
            public void run() {
                try {
                    sleep(2000);
                    if (mPref.getUserId() > 0 && mPref.getEmail() != null
                            && mPref.getMobile() != null && mPref.isValidated()) {
                        mHandler.sendEmptyMessage(MSG_START_MAIN);
                    } else {
                        mHandler.sendEmptyMessage(MSG_START_ANIMATION);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();

        findViewById(R.id.btn_next).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_next:
                register();
                break;
        }
    }

    private void slideDown(View view) {
        view.setVisibility(View.VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                0, // fromYDelta
                500); // toYDelta
        animate.setDuration(0);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }


    private void slideUp(View view) {
        view.setVisibility(View.VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0, // fromXDelta
                0, // toXDelta
                500, // fromYDelta
                0); // toYDelta
        animate.setDuration(1000);
        animate.setFillAfter(true);
        animate.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mParentForm.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        view.startAnimation(animate);
    }

    private void register() {
        GeekUtility.showProgressDialog(this, "Loading...");
        new Thread() {
            public void run() {
                try {
                    // Register
                    long uid = UserAPI.register(mEtEmail.getText().toString(), mEtMobile.getText().toString());
                    if (uid > 0) {
                        mPref.setUserId(uid);
                        mPref.setEmail(mEtEmail.getText().toString());
                        mPref.setMobile(mEtMobile.getText().toString());
                        mHandler.sendEmptyMessage(MSG_START_VALIDATION);
                    } else {
                        mMessage = UserAPI.errorMessage;
                        mHandler.sendEmptyMessage(MSG_SHOW_TOAST);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void startMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        startActivity(intent);
    }

    private void startValidationActivity() {
        Intent intent = new Intent(getApplicationContext(), ValidationActivity.class);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        startActivity(intent);
    }

}
