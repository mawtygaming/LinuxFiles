package com.codegeek.hypetrikedriver.model;

import java.io.Serializable;

public class Booking implements Serializable {

    private long id;
    private String riderFullName;
    private Coordinate pickup;
    private String pickupName;
    private Coordinate dropoff;
    private String dropoffName;
    private int distance;
    private int duration;
    private Price price;
    private String msg;
    private long timeout;

    public Booking() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRiderFullName() {
        return riderFullName;
    }

    public void setRiderFullName(String riderFullName) {
        this.riderFullName = riderFullName;
    }

    public Coordinate getPickup() {
        return pickup;
    }

    public void setPickup(Coordinate pickup) {
        this.pickup = pickup;
    }

    public String getPickupName() {
        return pickupName;
    }

    public void setPickupName(String pickupName) {
        this.pickupName = pickupName;
    }

    public Coordinate getDropoff() {
        return dropoff;
    }

    public void setDropoff(Coordinate dropoff) {
        this.dropoff = dropoff;
    }

    public String getDropoffName() {
        return dropoffName;
    }

    public void setDropoffName(String dropoffName) {
        this.dropoffName = dropoffName;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(long timeout) {
        this.timeout = timeout;
    }
}
